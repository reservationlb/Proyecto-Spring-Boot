<# : batch portion
@REM ----------------------------------------------------------------------------
@REM Maven Wrapper (modo "only-script") para LatinBurger - Windows.
@REM Lee distributionUrl de .mvn\wrapper\maven-wrapper.properties, descarga Maven
@REM la primera vez en %USERPROFILE%\.m2\wrapper\dists y lo reutiliza despues.
@REM ----------------------------------------------------------------------------
@ECHO OFF
@SETLOCAL
@SET __MVNW_ARG0_NAME__=%~nx0
@SET __MVNW_CMD__=
@SET __MVNW_ERROR__=
@SET __MVNW_PSMODULEP_SAVE=%PSModulePath%
@SET PSModulePath=
@FOR /F "usebackq tokens=1* delims==" %%A IN (`powershell -noprofile "& {$scriptDir='%~dp0'; $script='%__MVNW_ARG0_NAME__%'; icm -ScriptBlock ([Scriptblock]::Create((Get-Content -Raw '%~f0'))) -NoNewScope}"`) DO @(
  IF "%%A"=="MVN_CMD" (set __MVNW_CMD__=%%B) ELSE IF "%%B"=="" (echo %%A) ELSE (echo %%A=%%B)
)
@SET PSModulePath=%__MVNW_PSMODULEP_SAVE%
@SET __MVNW_PSMODULEP_SAVE=
@SET __MVNW_ARG0_NAME__=
@IF NOT "%__MVNW_CMD__%"=="" (
  @SET MAVEN_PROJECTBASEDIR=%~dp0
  "%__MVNW_CMD__%" %*
  @EXIT /B %ERRORLEVEL%
)
@ECHO No se pudo preparar Maven. Revise el mensaje anterior. 1>&2
@EXIT /B 1
: end batch / begin powershell #>

$ErrorActionPreference = "Stop"
$propsFile = Join-Path $scriptDir ".mvn\wrapper\maven-wrapper.properties"
$distributionUrl = (Get-Content -Raw $propsFile | ConvertFrom-StringData).distributionUrl
if (-not $distributionUrl) { Write-Error "distributionUrl no esta definido en $propsFile" }

$distributionName = $distributionUrl -replace '^.*/', ''
$distributionDir = $distributionName -replace '-bin\.zip$', ''

$sha = [System.Security.Cryptography.SHA256]::Create()
$hash = ($sha.ComputeHash([System.Text.Encoding]::UTF8.GetBytes($distributionUrl)) | ForEach-Object { $_.ToString("x2") }) -join ''
$hash = $hash.Substring(0, 16)

$mavenUserHome = if ($env:MAVEN_USER_HOME) { $env:MAVEN_USER_HOME } else { Join-Path $HOME ".m2" }
$mavenHome = Join-Path $mavenUserHome "wrapper\dists\$distributionDir\$hash"
$mvnCmd = Join-Path $mavenHome "$distributionDir\bin\mvn.cmd"

if (-not (Test-Path -Path $mvnCmd -PathType Leaf)) {
  Write-Host "Descargando $distributionUrl" -ForegroundColor Cyan
  $tmp = Join-Path ([System.IO.Path]::GetTempPath()) ([System.IO.Path]::GetRandomFileName())
  New-Item -ItemType Directory -Path $tmp | Out-Null
  try {
    $zip = Join-Path $tmp $distributionName
    $client = New-Object System.Net.WebClient
    if ($env:MVNW_USERNAME) {
      $client.Credentials = New-Object System.Net.NetworkCredential($env:MVNW_USERNAME, $env:MVNW_PASSWORD)
    }
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $client.DownloadFile($distributionUrl, $zip)
    $extract = Join-Path $tmp "extract"
    Expand-Archive -Path $zip -DestinationPath $extract
    New-Item -ItemType Directory -Force -Path (Split-Path $mavenHome) | Out-Null
    if (Test-Path $mavenHome) { Remove-Item -Recurse -Force $mavenHome }
    Move-Item -Path $extract -Destination $mavenHome
  } finally {
    if (Test-Path $tmp) { Remove-Item -Recurse -Force $tmp }
  }
}

Write-Output "MVN_CMD=$mvnCmd"
