# LatinBurger — Reservation L.B. (Spring Boot + Maven)

Migración del proyecto **LatinBurger** (NetBeans + Ant + Servlets + JSP + JDBC + GlassFish) a
**Spring Boot 3.5 + Maven + Spring MVC + Spring Data JPA/Hibernate + Thymeleaf + MySQL**.
Se conservan las rutas, la lógica de negocio, el esquema de la base de datos `reservation_lb`
y la interfaz visual (mismos CSS, mismas clases, mismos textos).

---

## 1. Requisitos

| Herramienta | Versión |
|---|---|
| JDK | 17 o superior |
| MySQL | 8.x con la base de datos `reservation_lb` ya creada (script base + `migracion_v1.sql` + `migracion_v2.sql`) |
| Maven | No es necesario instalarlo: se usa el Maven Wrapper (`mvnw` / `mvnw.cmd`) |
| IDE | IntelliJ IDEA (abrir la carpeta `LatinBurger`; se detecta como proyecto Maven) |

> La aplicación **no crea ni modifica** el esquema (`spring.jpa.hibernate.ddl-auto=none`).
> Los scripts `docs/sql/migracion_v1.sql` y `docs/sql/migracion_v2.sql` se incluyen solo como
> referencia; deben haberse ejecutado antes sobre la base de datos, igual que en el proyecto original.

## 2. Configuración de la conexión

`src/main/resources/application.properties` lee la conexión de variables de entorno. Si no se
definen, usa el MySQL de **Laragon** (localhost:**3307**, `root`, sin contraseña), donde está la base
`reservation_lb`. En el puerto 3306 corre el servicio `MySQL80`, que exige contraseña y no tiene esta
base: conectarse ahí provocaba el error *"Unable to determine Dialect without JDBC metadata"*.

| Variable | Valor por defecto |
|---|---|
| `DB_HOST` / `DB_PORT` / `DB_NAME` | `localhost` / `3307` / `reservation_lb` |
| `DB_URL` (reemplaza a las tres anteriores) | `jdbc:mysql://localhost:3307/reservation_lb?serverTimezone=UTC&characterEncoding=UTF-8&useSSL=false&allowPublicKeyRetrieval=true` |
| `DB_USERNAME` | `root` |
| `DB_PASSWORD` | *(vacío)* |
| `SERVER_PORT` | `8080` |

Ejemplos:

```bash
# Linux / macOS
export DB_USERNAME=latinburger
export DB_PASSWORD='mi-clave'
```

```powershell
# Windows PowerShell
$env:DB_USERNAME="latinburger"
$env:DB_PASSWORD="mi-clave"
```

En IntelliJ: *Run → Edit Configurations → LatinBurgerApplication → Environment variables*.

## 3. Ejecución

```bash
./mvnw clean test          # pruebas unitarias
./mvnw clean package       # genera target/LatinBurger-1.0.0.jar
./mvnw spring-boot:run     # levanta la aplicación en http://localhost:8080/
```

En Windows usar `mvnw.cmd` en lugar de `./mvnw`. La primera vez el wrapper descarga Maven 3.9.11
en `~/.m2/wrapper/dists` (necesita acceso a internet).

También se puede ejecutar el JAR: `java -jar target/LatinBurger-1.0.0.jar`.

### Prueba contra la base de datos real (opcional)

`BaseDeDatosTest` reemplaza las clases `Pruebas/PruebaConsultar*` y `PruebaConexion`: ejecuta
**solo consultas** (no inserta, actualiza ni borra) para comprobar que el mapeo JPA coincide con
el esquema real. Se activa con una variable de entorno:

```bash
LATINBURGER_DB_TEST=true ./mvnw test
```

## 4. Estructura

```
LatinBurger/
├── .idea/                          configuración básica de IntelliJ (JDK 17, Maven, UTF-8)
├── .mvn/wrapper/                   Maven Wrapper
├── docs/sql/                       migracion_v1.sql y migracion_v2.sql (referencia)
├── src/main/java/com/latinburger/
│   ├── LatinBurgerApplication.java
│   ├── config/                     interceptor de sesión, rutas de recursos, nombres de atributos de sesión
│   ├── controller/vista/           controladores de pantallas (antes Servlets)
│   ├── controller/api/             endpoints JSON del administrador
│   ├── dto/                        ItemCarrito (pedido en sesión)
│   ├── entity/                     entidades JPA (antes paquete Modelo)
│   ├── repository/                 Spring Data JPA (antes DAO del paquete Controlador)
│   ├── service/                    lógica de negocio (@Service, @Transactional)
│   └── util/                       Formato (formatos de moneda/estado usados en las vistas)
├── src/main/resources/
│   ├── static/css/                 web/Css/*.css (mismos nombres)
│   ├── static/css/administrador/   web/CssAdministrador/Admin.css
│   ├── static/img/  static/js/     destino de web/Imagenes y web/JavaScript (ver §8)
│   ├── templates/cliente/          vistas del cliente (antes View/Cliente/*.jsp)
│   ├── templates/administrador/    vistas del administrador (antes View/Administrador/*.jsp)
│   ├── templates/fragments/        layout admin (antes _AdminLayout*.jsp) y barra/progreso del cliente
│   └── application.properties
└── src/test/java/com/latinburger/  pruebas
```

## 5. Correspondencia Servlet → controlador (las URL se conservan)

| URL | Antes | Ahora |
|---|---|---|
| `/`, `/Inicio`, `/InicioServlet` | InicioServlet | `InicioController` |
| `/LoginServlet`, `/LogoutServlet`, `/RegistroServlet` | Login/Logout/RegistroServlet | `AutenticacionController` |
| `/Reservar`, `/DisponibilidadServlet`, `/EventoServlet`, `/DecoracionServlet`, `/ColorServlet`, `/MenuServlet`, `/ResumenServlet` | asistente de reserva | `ReservaClienteController` |
| `/PanelClienteServlet`, `/MisPedidosServlet`, `/FacturaServlet` | panel, pedidos, factura | `ClienteController` |
| `/AdminDashboardServlet`, `/AdminReportesServlet` | dashboard y reportes | `AdminDashboardController` |
| `/AdminReservasServlet`, `/AdminReservaFormServlet` | reservas / nuevo pedido | `AdminReservasController` |
| `/AdminMenuServlet`, `/AdminMenuFormServlet` | menú | `AdminMenuController` |
| `/AdminUsuariosServlet`, `/AdminUsuarioFormServlet` | usuarios | `AdminUsuariosController` |
| `/AdminCatalogosServlet` | eventos, decoraciones, colores | `AdminCatalogosController` |
| `/AdminDisponibilidadServlet` | horarios | `AdminDisponibilidadController` |
| `/AdminAbonosServlet` | abonos | `AdminAbonosController` |
| `/View/Cliente/Inicio.jsp`, `/Login.jsp`, `/Registro.jsp`, `/Index.jsp` | JSP directas | redirección (`LegacyRedirectController`) |

### Endpoints JSON (solo administrador, `controller/api`)

Las operaciones de `RolDAO`, `PermisoDAO`, `PermisoHasRolDAO`, `TipoDocumentoDAO` y `TipoMenuDAO`
no tenían pantalla en el proyecto original (solo se usaban desde las clases de `Pruebas`). Se
exponen como API para no perderlas:

| Recurso | Operaciones |
|---|---|
| `/api/admin/roles` | `GET` (`?todos=true`), `GET /{id}`, `POST`, `PUT /{id}`, `POST /{id}/activar`, `POST /{id}/inactivar`, `DELETE /{id}` |
| `/api/admin/permisos` | CRUD + `GET /rol/{idRol}`, `GET/POST/DELETE /{idPermiso}/rol/{idRol}` (permiso_has_rol) |
| `/api/admin/tipos-documento` | CRUD (el id se envía en el cuerpo, como en el DAO) |
| `/api/admin/tipos-menu` | CRUD + `GET /personalizado` |

Requieren una sesión iniciada con rol administrador (sin ella responden `401`).

## 6. Autenticación y autorización

Se conserva el mecanismo original (sesión HTTP), **sin Spring Security**:

* Login por número de documento + contraseña contra `usuario.documento` / `usuario.password`.
  Las contraseñas existentes siguen funcionando porque **no se cambió** la forma de compararlas.
* Atributos de sesión idénticos: `usuarioLogueado`, `nombreCliente`, `rolId` y los del asistente
  (`reservaFecha`, `reservaHora`, `reservaIdDisponibilidad`, …, `carritoProductos`, `ultimaReservaId`).
* `rol_id_rol = 1` → administrador (va a `/AdminDashboardServlet`); el resto → `/PanelClienteServlet`.
* `AutenticacionInterceptor` aplica las mismas reglas que repetía cada Servlet: rutas de cliente
  exigen sesión; rutas `/Admin*` y `/api/admin/**` exigen rol 1; si no se cumple → `/LoginServlet`.
* Un cliente solo ve sus reservas y sus facturas; el administrador puede ver cualquier factura.

Único ajuste de seguridad: al iniciar sesión se renueva el identificador de sesión
(`changeSessionId`) para evitar la fijación de sesión. No afecta a los usuarios existentes.

> Recomendación (no aplicada para no romper la compatibilidad): las contraseñas se guardan en texto
> plano en la tabla `usuario`, igual que antes. Migrarlas a BCrypt requiere un proceso de
> re-cifrado de los usuarios existentes.

## 7. Notas de la migración

* **Esquema intacto:** nombres exactos de tablas y columnas (incluida la mayúscula de `Producto` y
  `Categoria`), mediante `PhysicalNamingStrategyStandardImpl` y `@Column(name=…)` en cada campo.
  Las claves foráneas se mapean como columnas simples (como en el modelo original), sin inventar
  relaciones JPA. `permiso_has_rol` usa clave compuesta (`@IdClass`).
* Campos del modelo original que **no son columnas** (`Usuario.correo`, `Usuario.userName`,
  `Usuario.rolDescripcion`, `ReservaProducto.nombreProducto`) son `@Transient`.
* `abono.fecha_abono` la sigue asignando MySQL (`DEFAULT CURRENT_TIMESTAMP`).
* Fechas y horas se mapean con `LocalDate`/`LocalTime`/`LocalDateTime` para que el conector no
  desplace la hora por la zona horaria (el original evitaba lo mismo enviando las fechas como texto).
  Las vistas muestran exactamente el mismo texto que antes (`yyyy-MM-dd`, `HH:mm:ss`).
* **Confirmación de reserva transaccional** (`ReservaService.insertarReservaCompleta`): ocupa el
  horario con un `UPDATE … WHERE estado = 'Disponible'`, inserta la reserva, los platos y el abono;
  si otro cliente tomó el horario devuelve -1 y no escribe nada; cualquier error hace rollback.
* Los precios del carrito se vuelven a leer de la base de datos (no se confía en el navegador).
* `ReservaDAO.contarReservasMes` concatenaba año y mes en el SQL; ahora usa parámetros enlazados.
* Cuando un horario se pierde al confirmar, el mensaje "Justo acaban de reservar ese horario…" ahora
  sí se muestra en Disponibilidad (antes se perdía en la redirección).
* El enlace "Regístrate aquí" del login apuntaba a `Registro.jsp` directamente (sin cargar los tipos
  de documento); ahora apunta a `/RegistroServlet`.
* Los formatos numéricos (`String.format("%,.0f")`) y las clases CSS de estado se reproducen en
  `util/Formato`, usado desde Thymeleaf como `${@formato.moneda(...)}`.

## 8. Recursos estáticos e imágenes

* `web/Css/*` → `static/css/` y `web/CssAdministrador/Admin.css` → `static/css/administrador/`
  (mismos nombres). Las rutas antiguas `/Css/**` y `/CssAdministrador/**` siguen respondiendo.
* El ZIP recibido **no contenía** las carpetas `web/Imagenes` ni `web/JavaScript` (todo el JavaScript
  estaba embebido en las JSP y se conservó dentro de las plantillas). Las columnas `imagen` de la BD
  guardan rutas como `Imagenes/plato.jpg`; esa URL se sirve desde `static/img/`, así que basta con
  copiar las imágenes en `src/main/resources/static/img/` (manteniendo sus nombres) para que se
  muestren sin modificar ningún dato.

## 9. Pruebas incluidas

| Prueba | Qué verifica |
|---|---|
| `FormatoTest` | formatos de moneda, fecha y clases de estado idénticos a las JSP |
| `CarritoServiceTest` | interpretación de `carritoData` del cliente y del administrador |
| `ReservaServiceTest` | total del evento; reserva rechazada si el horario ya fue tomado; detalle y abono con el id generado |
| `AutenticacionInterceptorTest` | reglas de acceso cliente / administrador / API |
| `BaseDeDatosTest` | consultas reales contra MySQL (solo con `LATINBURGER_DB_TEST=true`) |

Las clases interactivas de `Pruebas/` del proyecto original (que pedían datos por consola e
insertaban/borraban registros) no se copiaron como tales porque modificarían datos reales.

## 10. Estado de la verificación

La migración se generó en un entorno **sin acceso a Maven Central ni a MySQL**, por lo que
`mvn clean test`, `mvn clean package` y `mvn spring-boot:run` **no se pudieron ejecutar** allí.
Sí se verificó:

* Todo el código Java (main y test) compila con `javac --release 17` contra interfaces
  equivalentes de las APIs usadas (JPA, Spring MVC/Data, Servlet, JUnit, Mockito).
* Todas las vistas referenciadas por los controladores existen; todos los enlaces `@{/…}` de las
  plantillas corresponden a una ruta mapeada; las hojas de estilo referenciadas existen; las
  etiquetas HTML de las plantillas están balanceadas.
* El Maven Wrapper descarga y lanza Maven correctamente.

Pendiente de comprobar en su equipo: ejecutar los tres comandos de la sección 3 con conexión a
internet y a la base `reservation_lb`, y recorrer el flujo completo (registro → login → reserva →
factura, y el panel del administrador). El script base de creación de tablas (`Scrip.sql`) no venía
en el ZIP; el mapeo se hizo a partir de las consultas SQL de los DAO y de las dos migraciones.
