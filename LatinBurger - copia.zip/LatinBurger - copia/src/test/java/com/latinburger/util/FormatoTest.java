package com.latinburger.util;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import org.junit.jupiter.api.Test;

/** Verifica que los formatos de presentación sean los mismos que usaban las JSP. */
class FormatoTest {

    private final Formato formato = new Formato();

    @Test
    void monedaUsaElMismoFormatoQueStringFormat() {
        assertEquals(String.format("%,.0f", 1500000d), formato.moneda(1500000d));
        assertEquals(String.format("%,.0f", new BigDecimal("250000.00")), formato.moneda(new BigDecimal("250000.00")));
        assertEquals("0", formato.moneda(null));
    }

    @Test
    void enteroTruncaComoElCastDeMenuForm() {
        assertEquals(12999L, formato.entero(12999.9));
    }

    @Test
    void fechaHoraConFormatoTimestamp() {
        assertEquals("2026-01-05 14:03:22.0", formato.fechaHora(LocalDateTime.of(2026, 1, 5, 14, 3, 22)));
        assertEquals("", formato.fechaHora(null));
    }

    @Test
    void claseBadgeDelPanelAdministrador() {
        assertEquals("badge-confirmada", formato.claseBadge("Confirmada"));
        assertEquals("badge-preparacion", formato.claseBadge("En preparación"));
        assertEquals("badge-entregada", formato.claseBadge("Entregada"));
        assertEquals("badge-cancelada", formato.claseBadge("Cancelada"));
        assertEquals("badge-pendiente", formato.claseBadge("Pendiente"));
        assertEquals("badge-pendiente", formato.claseBadge(null));
    }

    @Test
    void claseEstadoDelPanelCliente() {
        assertEquals("badge-En_preparacion", formato.claseEstadoCliente("En preparación"));
        assertEquals("badge-Pendiente", formato.claseEstadoCliente(null));
    }
}
