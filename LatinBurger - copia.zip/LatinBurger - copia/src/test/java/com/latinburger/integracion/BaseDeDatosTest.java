package com.latinburger.integracion;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import com.latinburger.service.CatalogoService;
import com.latinburger.service.DisponibilidadService;
import com.latinburger.service.ProductoService;
import com.latinburger.service.ReporteService;
import com.latinburger.service.ReservaService;
import com.latinburger.service.RolService;
import com.latinburger.service.TipoDocumentoService;
import com.latinburger.service.TipoMenuService;
import com.latinburger.service.UsuarioService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.EnabledIfEnvironmentVariable;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * Equivalente de solo lectura de las clases Pruebas/PruebaConsultar* y PruebaConexion del
 * proyecto original: verifica contra la base de datos real reservation_lb que el mapeo JPA
 * (tablas, columnas y consultas) coincide con el esquema. NO inserta, actualiza ni borra datos.
 *
 * Se ejecuta solo si existe la variable de entorno LATINBURGER_DB_TEST=true, para que
 * "mvn test" funcione en equipos sin MySQL.
 */
@SpringBootTest
@EnabledIfEnvironmentVariable(named = "LATINBURGER_DB_TEST", matches = "true")
class BaseDeDatosTest {

    @Autowired
    private RolService rolService;
    @Autowired
    private UsuarioService usuarioService;
    @Autowired
    private TipoDocumentoService tipoDocumentoService;
    @Autowired
    private TipoMenuService tipoMenuService;
    @Autowired
    private CatalogoService catalogoService;
    @Autowired
    private ProductoService productoService;
    @Autowired
    private DisponibilidadService disponibilidadService;
    @Autowired
    private ReservaService reservaService;
    @Autowired
    private ReporteService reporteService;

    @Test
    void consultasDeCatalogosFuncionanContraElEsquemaReal() {
        assertNotNull(rolService.listar(), "rol");
        assertNotNull(tipoDocumentoService.listar(), "tipo_documento");
        assertNotNull(tipoMenuService.listar(), "tipo_menu");
        assertNotNull(catalogoService.listarTodosEventos(), "tipo_evento");
        assertNotNull(catalogoService.listarTodasDecoraciones(), "tipo_decoracion");
        assertNotNull(catalogoService.listarTodosColores(), "color_evento");
        assertNotNull(catalogoService.listarCategorias(), "Categoria");
    }

    @Test
    void consultasDeProductosUsuariosYDisponibilidad() {
        assertNotNull(productoService.listarTodos(), "Producto");
        assertNotNull(productoService.obtenerListaMenu(), "Producto JOIN Categoria");
        assertNotNull(usuarioService.listar(), "usuario JOIN rol");
        assertNotNull(disponibilidadService.listarTodas(), "disponibilidad");
        assertNotNull(disponibilidadService.listarDisponibles(null), "disponibilidad disponible");
    }

    @Test
    void consultasDeReservasYReportes() {
        assertNotNull(reservaService.listarTodasConDetalle(), "reserva JOIN tipo_evento/tipo_decoracion/usuario");
        assertDoesNotThrow(() -> reporteService.datosDashboard());
        assertDoesNotThrow(() -> reporteService.datosReportes());
    }
}
