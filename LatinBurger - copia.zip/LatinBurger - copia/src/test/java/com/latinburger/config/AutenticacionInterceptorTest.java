package com.latinburger.config;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.latinburger.entity.Usuario;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import org.junit.jupiter.api.Test;

/** Reglas de acceso cliente / administrador que antes repetía cada Servlet. */
class AutenticacionInterceptorTest {

    private final AutenticacionInterceptor interceptor = new AutenticacionInterceptor();

    private static HttpServletRequest peticion(String ruta, HttpSession sesion) {
        HttpServletRequest request = mock(HttpServletRequest.class);
        when(request.getContextPath()).thenReturn("");
        when(request.getRequestURI()).thenReturn(ruta);
        when(request.getSession(false)).thenReturn(sesion);
        return request;
    }

    private static HttpSession sesion(int rolId) {
        HttpSession session = mock(HttpSession.class);
        when(session.getAttribute(SesionKeys.USUARIO_LOGUEADO)).thenReturn(new Usuario());
        when(session.getAttribute(SesionKeys.ROL_ID)).thenReturn(rolId);
        return session;
    }

    @Test
    void sinSesionRedirigeAlLogin() throws Exception {
        HttpServletResponse response = mock(HttpServletResponse.class);
        assertFalse(interceptor.preHandle(peticion("/PanelClienteServlet", null), response, null));
        verify(response).sendRedirect("/LoginServlet");
    }

    @Test
    void clienteConSesionEntraASuPanel() throws Exception {
        HttpServletResponse response = mock(HttpServletResponse.class);
        assertTrue(interceptor.preHandle(peticion("/PanelClienteServlet", sesion(2)), response, null));
    }

    @Test
    void clienteNoEntraAlPanelDeAdministrador() throws Exception {
        HttpServletResponse response = mock(HttpServletResponse.class);
        assertFalse(interceptor.preHandle(peticion("/AdminDashboardServlet", sesion(2)), response, null));
        verify(response).sendRedirect("/LoginServlet");
    }

    @Test
    void administradorEntraAlPanelDeAdministrador() throws Exception {
        HttpServletResponse response = mock(HttpServletResponse.class);
        assertTrue(interceptor.preHandle(peticion("/AdminDashboardServlet", sesion(1)), response, null));
    }

    @Test
    void apiDeAdministradorSinPermisoResponde401() throws Exception {
        HttpServletResponse response = mock(HttpServletResponse.class);
        assertFalse(interceptor.preHandle(peticion("/api/admin/roles", sesion(2)), response, null));
        verify(response).sendError(HttpServletResponse.SC_UNAUTHORIZED);
    }
}
