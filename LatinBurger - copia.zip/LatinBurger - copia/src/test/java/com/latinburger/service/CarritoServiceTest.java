package com.latinburger.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.latinburger.dto.ItemCarrito;
import com.latinburger.entity.Producto;
import com.latinburger.entity.ReservaProducto;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/** Reglas del carrito que antes estaban en MenuServlet.doPost y AdminReservaFormServlet.doPost. */
class CarritoServiceTest {

    private ProductoService productoService;
    private CarritoService carritoService;

    @BeforeEach
    void preparar() {
        productoService = mock(ProductoService.class);
        carritoService = new CarritoService(productoService);

        List<Map<String, String>> menu = new ArrayList<>();
        menu.add(plato("1", "Hamburguesa Latina", "25000"));
        menu.add(plato("2", "Papas", "8000"));
        when(productoService.obtenerListaMenu()).thenReturn(menu);
    }

    private static Map<String, String> plato(String id, String nombre, String precio) {
        Map<String, String> p = new HashMap<>();
        p.put("id", id);
        p.put("nombre", nombre);
        p.put("precio", precio);
        return p;
    }

    @Test
    void carritoClienteUsaPreciosDeLaBaseDeDatosEIgnoraEntradasInvalidas() {
        // 3 = producto inexistente/oculto, "x" = cantidad inválida, 0 = cantidad no positiva
        List<ItemCarrito> carrito = carritoService.parsearCarritoCliente("1:2,2:x,3:1,2:0,mal,2:3");

        assertEquals(2, carrito.size());
        assertEquals(1, carrito.get(0).getIdProducto());
        assertEquals(new BigDecimal("50000"), carrito.get(0).getSubtotal());
        assertEquals(new BigDecimal("24000"), carrito.get(1).getSubtotal());
        assertEquals(new BigDecimal("74000"), carritoService.totalCarrito(carrito));
    }

    @Test
    void carritoVacioDevuelveListaVacia() {
        assertTrue(carritoService.parsearCarritoCliente(null).isEmpty());
        assertTrue(carritoService.parsearCarritoCliente("  ").isEmpty());
    }

    @Test
    void carritoAdminTomaElPrecioDelProducto() {
        Producto p = new Producto(7, "Malteada", "", 12000, 3, null);
        when(productoService.consultar(7)).thenReturn(p);

        List<ReservaProducto> items = carritoService.parsearCarritoAdmin("7:2,99:1,7:0");

        assertEquals(1, items.size());
        assertEquals(new BigDecimal("24000.0"), items.get(0).getSubtotal());
    }

    @Test
    void carritoAdminConNumeroInvalidoLanzaExcepcionComoElServlet() {
        assertThrows(NumberFormatException.class, () -> carritoService.parsearCarritoAdmin("abc:1"));
    }
}
