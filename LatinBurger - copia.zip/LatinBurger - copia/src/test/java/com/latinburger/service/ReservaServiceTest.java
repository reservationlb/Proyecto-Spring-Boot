package com.latinburger.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.latinburger.entity.Abono;
import com.latinburger.entity.Reserva;
import com.latinburger.entity.ReservaProducto;
import com.latinburger.entity.TipoDecoracion;
import com.latinburger.entity.TipoEvento;
import com.latinburger.repository.ReservaRepository;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/** Reglas de ReservaDAO.insertarReservaCompleta y del cálculo del total del evento. */
class ReservaServiceTest {

    private ReservaRepository reservaRepository;
    private DisponibilidadService disponibilidadService;
    private ReservaProductoService reservaProductoService;
    private AbonoService abonoService;
    private ReservaService reservaService;

    @BeforeEach
    void preparar() {
        reservaRepository = mock(ReservaRepository.class);
        disponibilidadService = mock(DisponibilidadService.class);
        reservaProductoService = mock(ReservaProductoService.class);
        abonoService = mock(AbonoService.class);
        reservaService = new ReservaService(reservaRepository, disponibilidadService, reservaProductoService, abonoService);
    }

    @Test
    void totalEsEventoMasDecoracionMasPlatos() {
        TipoEvento evento = new TipoEvento(1, "Cumpleaños", "", new BigDecimal("100000"));
        TipoDecoracion decoracion = new TipoDecoracion(1, "Globos", "", new BigDecimal("50000"));

        assertEquals(new BigDecimal("175000"),
                reservaService.calcularTotal(evento, decoracion, new BigDecimal("25000")));
        assertEquals(new BigDecimal("25000"), reservaService.calcularTotal(null, null, new BigDecimal("25000")));
    }

    @Test
    void siElHorarioYaFueTomadoDevuelveMenosUnoSinInsertar() {
        Reserva reserva = new Reserva();
        reserva.setDisponibilidadIdDisponibilidad(5);
        when(disponibilidadService.ocuparDisponibilidad(5)).thenReturn(false);

        int resultado = reservaService.insertarReservaCompleta(reserva, new ArrayList<>(), null);

        assertEquals(ReservaService.HORARIO_NO_DISPONIBLE, resultado);
        verify(reservaRepository, never()).saveAndFlush(any(Reserva.class));
    }

    @Test
    void reservaConfirmadaGuardaDetalleYAbonoConElIdGenerado() {
        Reserva reserva = new Reserva();
        reserva.setDisponibilidadIdDisponibilidad(5);
        Reserva guardada = new Reserva();
        guardada.setIdReserva(42);
        when(disponibilidadService.ocuparDisponibilidad(5)).thenReturn(true);
        when(reservaRepository.saveAndFlush(reserva)).thenReturn(guardada);

        ReservaProducto item = new ReservaProducto();
        item.setCantidad(2);
        item.setPrecioUnitario(new BigDecimal("10000"));
        List<ReservaProducto> items = new ArrayList<>();
        items.add(item);
        Abono abono = new Abono();
        abono.setMedioPago("Nequi");
        abono.setValorAbono(new BigDecimal("20000"));

        int id = reservaService.insertarReservaCompleta(reserva, items, abono);

        assertEquals(42, id);
        assertEquals("Pendiente", reserva.getEstado());
        assertEquals(42, item.getReservaIdReserva());
        assertEquals(42, abono.getReservaIdReserva());
        verify(reservaProductoService).insertar(item);
        verify(abonoService).insertar(abono);
    }
}
