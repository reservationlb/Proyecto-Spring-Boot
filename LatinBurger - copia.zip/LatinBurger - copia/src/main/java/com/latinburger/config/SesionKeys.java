package com.latinburger.config;

/**
 * Nombres de los atributos de sesión. Son exactamente los mismos que usaban
 * los Servlets originales, para conservar el comportamiento del asistente de reserva.
 */
public final class SesionKeys {

    public static final String USUARIO_LOGUEADO = "usuarioLogueado";
    public static final String NOMBRE_CLIENTE = "nombreCliente";
    public static final String ROL_ID = "rolId";

    public static final String RESERVA_FECHA = "reservaFecha";
    public static final String RESERVA_HORA = "reservaHora";
    public static final String RESERVA_ID_DISPONIBILIDAD = "reservaIdDisponibilidad";
    public static final String RESERVA_ID_TIPO_EVENTO = "reservaIdTipoEvento";
    public static final String RESERVA_NUMERO_PERSONAS = "reservaNumeroPersonas";
    public static final String RESERVA_ID_TIPO_DECORACION = "reservaIdTipoDecoracion";
    public static final String RESERVA_COLOR = "reservaColor";
    public static final String RESERVA_COMENTARIOS = "reservaComentarios";
    public static final String CARRITO_PRODUCTOS = "carritoProductos";
    public static final String ULTIMA_RESERVA_ID = "ultimaReservaId";

    /** rol_id_rol = 1 -> Administrador (según el script de base de datos original). */
    public static final int ROL_ADMINISTRADOR = 1;

    /** rol_id_rol = 2 -> Cliente (rol por defecto en el registro). */
    public static final int ROL_CLIENTE = 2;

    private SesionKeys() {
    }
}
