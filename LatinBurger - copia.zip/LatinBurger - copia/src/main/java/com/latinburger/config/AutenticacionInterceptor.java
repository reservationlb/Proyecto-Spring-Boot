package com.latinburger.config;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

/**
 * Centraliza las validaciones de sesión que cada Servlet hacía al inicio de doGet/doPost:
 * <ul>
 *   <li>Rutas de cliente: requieren "usuarioLogueado" en sesión; si no, redirigen a /LoginServlet.</li>
 *   <li>Rutas /Admin* y /api/admin/**: además requieren rolId == 1 (AdminDashboardServlet.esAdmin).</li>
 * </ul>
 * Se conserva el mecanismo de autenticación original (sesión HTTP) sin Spring Security.
 */
@Component
public class AutenticacionInterceptor implements HandlerInterceptor {

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
            throws Exception {
        String ruta = request.getRequestURI().substring(request.getContextPath().length());
        boolean rutaAdmin = ruta.startsWith("/Admin") || ruta.startsWith("/api/admin");

        if (rutaAdmin ? esAdmin(request) : haySesion(request)) {
            return true;
        }
        if (ruta.startsWith("/api/")) {
            response.sendError(HttpServletResponse.SC_UNAUTHORIZED);
        } else {
            response.sendRedirect(request.getContextPath() + "/LoginServlet");
        }
        return false;
    }

    public static boolean haySesion(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        return session != null && session.getAttribute(SesionKeys.USUARIO_LOGUEADO) != null;
    }

    /** Equivalente a AdminDashboardServlet.esAdmin(request). */
    public static boolean esAdmin(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        return session != null && session.getAttribute(SesionKeys.USUARIO_LOGUEADO) != null
                && Integer.valueOf(SesionKeys.ROL_ADMINISTRADOR).equals(session.getAttribute(SesionKeys.ROL_ID));
    }
}
