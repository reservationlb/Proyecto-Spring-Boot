package com.latinburger.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebConfig implements WebMvcConfigurer {

    private final AutenticacionInterceptor autenticacionInterceptor;

    public WebConfig(AutenticacionInterceptor autenticacionInterceptor) {
        this.autenticacionInterceptor = autenticacionInterceptor;
    }

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(autenticacionInterceptor)
                .addPathPatterns(
                        // Área del cliente (requieren sesión iniciada)
                        "/PanelClienteServlet", "/MisPedidosServlet", "/FacturaServlet",
                        "/DisponibilidadServlet", "/EventoServlet", "/DecoracionServlet",
                        "/ColorServlet", "/MenuServlet", "/ResumenServlet",
                        // Área del administrador (requieren rol administrador)
                        "/Admin*", "/Admin*/**", "/api/admin/**");
    }

    /**
     * Las columnas "imagen" de Producto, tipo_evento, tipo_decoracion y color_evento guardan
     * rutas relativas como "Imagenes/plato.jpg" (carpeta web/Imagenes del proyecto original).
     * Esa ruta se sigue sirviendo desde static/img para no tener que modificar los datos.
     * También se mantienen las rutas antiguas /Css/** y /CssAdministrador/**.
     */
    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("/Imagenes/**").addResourceLocations("classpath:/static/img/");
        registry.addResourceHandler("/JavaScript/**").addResourceLocations("classpath:/static/js/");
        registry.addResourceHandler("/Css/**").addResourceLocations("classpath:/static/css/");
        registry.addResourceHandler("/CssAdministrador/**").addResourceLocations("classpath:/static/css/administrador/");
    }
}
