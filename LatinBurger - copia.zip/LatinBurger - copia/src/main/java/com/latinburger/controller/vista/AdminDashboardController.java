package com.latinburger.controller.vista;

import com.latinburger.service.ReporteService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * Dashboard y reportes del administrador (antes AdminDashboardServlet y AdminReportesServlet).
 * El acceso solo de administradores lo valida AutenticacionInterceptor (rutas /Admin*).
 */
@Controller
public class AdminDashboardController {

    private final ReporteService reporteService;

    public AdminDashboardController(ReporteService reporteService) {
        this.reporteService = reporteService;
    }

    @GetMapping("/AdminDashboardServlet")
    public String dashboard(Model model) {
        model.addAllAttributes(reporteService.datosDashboard());
        model.addAttribute("seccionActiva", "dashboard");
        return "administrador/Dashboard";
    }

    @GetMapping("/AdminReportesServlet")
    public String reportes(Model model) {
        model.addAllAttributes(reporteService.datosReportes());
        model.addAttribute("seccionActiva", "reportes");
        return "administrador/Reportes";
    }
}
