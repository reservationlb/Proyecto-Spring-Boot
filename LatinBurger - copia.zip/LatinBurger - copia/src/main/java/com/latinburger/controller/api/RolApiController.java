package com.latinburger.controller.api;

import com.latinburger.entity.Rol;
import com.latinburger.service.RolService;
import java.util.List;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * Endpoints JSON de roles (operaciones de RolDAO que en el proyecto original no tenían
 * pantalla y solo se ejecutaban desde las clases de Pruebas). Solo administradores.
 */
@RestController
@RequestMapping("/api/admin/roles")
public class RolApiController {

    private final RolService rolService;

    public RolApiController(RolService rolService) {
        this.rolService = rolService;
    }

    /** ?todos=true incluye los inactivos; por defecto solo activos (RolDAO.listar). */
    @GetMapping
    public List<Rol> listar(@RequestParam(value = "todos", defaultValue = "false") boolean todos) {
        return todos ? rolService.listarTodos() : rolService.listar();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Rol> consultar(@PathVariable int id) {
        Rol rol = rolService.consultarRol(id);
        return rol != null ? ResponseEntity.ok(rol) : ResponseEntity.notFound().build();
    }

    @PostMapping
    public ResponseEntity<Boolean> insertar(@RequestBody Rol rol) {
        return ResponseEntity.ok(rolService.insertarRol(rol));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Boolean> actualizar(@PathVariable int id, @RequestBody Rol rol) {
        rol.setIdRol(id);
        return resultado(rolService.actualizarRol(rol));
    }

    @PostMapping("/{id}/activar")
    public ResponseEntity<Boolean> activar(@PathVariable int id) {
        return resultado(rolService.activarRol(id));
    }

    @PostMapping("/{id}/inactivar")
    public ResponseEntity<Boolean> inactivar(@PathVariable int id) {
        return resultado(rolService.inactivarRol(id));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Boolean> eliminar(@PathVariable int id) {
        return resultado(rolService.eliminarRol(id));
    }

    static ResponseEntity<Boolean> resultado(boolean ok) {
        return ok ? ResponseEntity.ok(true) : ResponseEntity.notFound().build();
    }
}
