package com.latinburger.controller.vista;

import com.latinburger.entity.Usuario;
import com.latinburger.service.RolService;
import com.latinburger.service.TipoDocumentoService;
import com.latinburger.service.UsuarioService;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

/** Gestión de usuarios del administrador (antes AdminUsuariosServlet y AdminUsuarioFormServlet). */
@Controller
public class AdminUsuariosController {

    private final UsuarioService usuarioService;
    private final RolService rolService;
    private final TipoDocumentoService tipoDocumentoService;

    public AdminUsuariosController(UsuarioService usuarioService, RolService rolService,
                                   TipoDocumentoService tipoDocumentoService) {
        this.usuarioService = usuarioService;
        this.rolService = rolService;
        this.tipoDocumentoService = tipoDocumentoService;
    }

    @GetMapping("/AdminUsuariosServlet")
    public String listar(Model model) {
        model.addAttribute("usuarios", usuarioService.listar());
        model.addAttribute("seccionActiva", "usuarios");
        return "administrador/Usuarios";
    }

    /** Activar / inactivar usuario. */
    @PostMapping("/AdminUsuariosServlet")
    public String cambiarEstado(@RequestParam(value = "accion", required = false) String accion,
                                @RequestParam(value = "idUsuario", required = false) String idUsuarioStr) {
        try {
            int idUsuario = Integer.parseInt(idUsuarioStr);
            if ("activar".equals(accion)) {
                usuarioService.activarUsuario(idUsuario);
            } else if ("inactivar".equals(accion)) {
                usuarioService.inactivarUsuario(idUsuario);
            }
        } catch (NumberFormatException ignored) {
            // id inválido: se ignora, igual que en el Servlet original
        }
        return "redirect:/AdminUsuariosServlet";
    }

    @GetMapping("/AdminUsuarioFormServlet")
    public String formulario(@RequestParam(value = "id", required = false) String idStr, Model model) {
        Usuario usuario = null;
        if (idStr != null) {
            try {
                usuario = usuarioService.consultarPorId(Integer.parseInt(idStr));
            } catch (NumberFormatException ignored) {
                // se muestra el formulario de alta
            }
        }
        model.addAttribute("usuario", usuario);
        cargarCatalogos(model);
        return "administrador/UsuarioForm";
    }

    @PostMapping("/AdminUsuarioFormServlet")
    public String guardar(@RequestParam(value = "idUsuario", required = false) String idStr,
                          @RequestParam(value = "nombre", required = false) String nombre,
                          @RequestParam(value = "apellido", required = false) String apellido,
                          @RequestParam(value = "direccion", required = false) String direccion,
                          @RequestParam(value = "telefono", required = false) String telefono,
                          @RequestParam(value = "tipoDocumentoId", required = false) String tipoDocumentoId,
                          @RequestParam(value = "numeroDocumento", required = false) String numeroDocumento,
                          @RequestParam(value = "fechaNacimiento", required = false) String fechaNac,
                          @RequestParam(value = "contrasena", required = false) String contrasena,
                          @RequestParam(value = "rolId", required = false) String rolId,
                          Model model) {
        try {
            boolean esNuevo = (idStr == null || idStr.trim().isEmpty() || "0".equals(idStr));
            if (esNuevo) {
                if (numeroDocumento == null || numeroDocumento.isBlank() || contrasena == null || contrasena.isBlank()
                        || nombre == null || nombre.isBlank() || apellido == null || apellido.isBlank()) {
                    throw new IllegalArgumentException("campos obligatorios");
                }
                numeroDocumento = numeroDocumento.trim();
                if (usuarioService.existeDocumento(numeroDocumento)) {
                    model.addAttribute("error", "Ya existe un usuario con ese número de documento.");
                    cargarCatalogos(model);
                    return "administrador/UsuarioForm";
                }
                Usuario nuevo = new Usuario();
                nuevo.setNombre(nombre);
                nuevo.setApellido(apellido);
                nuevo.setTipoDocumentoIdTipoDocumento(Integer.parseInt(tipoDocumentoId));
                nuevo.setNumeroDocumento(numeroDocumento);
                nuevo.setDireccion(direccion);
                nuevo.setTelefono(telefono);
                nuevo.setFechaNacimiento(fechaNac != null && !fechaNac.trim().isEmpty()
                        ? LocalDate.parse(fechaNac) : LocalDate.of(2000, 1, 1));
                nuevo.setContrasena(contrasena);
                nuevo.setRolIdRol(Integer.parseInt(rolId));
                nuevo.setEstado("Activo");
                if (nuevo.getDireccion() == null) {
                    nuevo.setDireccion("");
                }
                if (nuevo.getTelefono() == null) {
                    nuevo.setTelefono("");
                }
                if (!usuarioService.insertarUsuario(nuevo)) {
                    model.addAttribute("error", "No se pudo crear el usuario. Verifica los datos e inténtalo de nuevo.");
                    cargarCatalogos(model);
                    return "administrador/UsuarioForm";
                }
            } else {
                Usuario existente = new Usuario();
                existente.setIdUsuario(Integer.parseInt(idStr));
                existente.setNombre(nombre);
                existente.setApellido(apellido);
                existente.setDireccion(direccion);
                existente.setTelefono(telefono);
                usuarioService.actualizarUsuario(existente);
            }
            return "redirect:/AdminUsuariosServlet";
        } catch (IllegalArgumentException | DateTimeParseException e) {
            model.addAttribute("error", "Revisa que todos los campos obligatorios estén completos y correctos.");
            if (idStr != null && !idStr.isBlank() && !"0".equals(idStr)) {
                try {
                    model.addAttribute("usuario", usuarioService.consultarPorId(Integer.parseInt(idStr)));
                } catch (NumberFormatException ignored) {
                    // se muestra el formulario de alta
                }
            }
            cargarCatalogos(model);
            return "administrador/UsuarioForm";
        }
    }

    private void cargarCatalogos(Model model) {
        model.addAttribute("roles", rolService.listar());
        model.addAttribute("tiposDocumento", tipoDocumentoService.listar());
        model.addAttribute("seccionActiva", "usuarios");
    }
}
