package com.latinburger.controller.api;

import com.latinburger.entity.Permiso;
import com.latinburger.entity.PermisoHasRol;
import com.latinburger.service.PermisoService;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Endpoints JSON de permisos y de su asignación a roles (PermisoDAO y PermisoHasRolDAO).
 * Solo administradores.
 */
@RestController
@RequestMapping("/api/admin/permisos")
public class PermisoApiController {

    private final PermisoService permisoService;

    public PermisoApiController(PermisoService permisoService) {
        this.permisoService = permisoService;
    }

    @GetMapping
    public List<Permiso> listar() {
        return permisoService.listar();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Permiso> consultar(@PathVariable int id) {
        Permiso permiso = permisoService.consultarPermiso(id);
        return permiso != null ? ResponseEntity.ok(permiso) : ResponseEntity.notFound().build();
    }

    @PostMapping
    public ResponseEntity<Boolean> insertar(@RequestBody Permiso permiso) {
        return ResponseEntity.ok(permisoService.insertarPermiso(permiso));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Boolean> actualizar(@PathVariable int id, @RequestBody Permiso permiso) {
        permiso.setIdPermiso(id);
        return RolApiController.resultado(permisoService.actualizarPermiso(permiso));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Boolean> eliminar(@PathVariable int id) {
        return RolApiController.resultado(permisoService.eliminarPermiso(id));
    }

    // ------------------------- permiso_has_rol -------------------------

    @GetMapping("/rol/{idRol}")
    public List<PermisoHasRol> listarPorRol(@PathVariable int idRol) {
        return permisoService.listarPorRol(idRol);
    }

    @GetMapping("/{idPermiso}/rol/{idRol}")
    public ResponseEntity<PermisoHasRol> consultarAsignacion(@PathVariable int idPermiso, @PathVariable int idRol) {
        PermisoHasRol relacion = permisoService.consultarPermisoHasRol(idPermiso, idRol);
        return relacion != null ? ResponseEntity.ok(relacion) : ResponseEntity.notFound().build();
    }

    @PostMapping("/{idPermiso}/rol/{idRol}")
    public ResponseEntity<Boolean> asignar(@PathVariable int idPermiso, @PathVariable int idRol) {
        boolean ok = permisoService.insertarPermisoHasRol(new PermisoHasRol(idPermiso, idRol));
        return ok ? ResponseEntity.ok(true) : ResponseEntity.status(HttpStatus.CONFLICT).body(false);
    }

    @DeleteMapping("/{idPermiso}/rol/{idRol}")
    public ResponseEntity<Boolean> quitar(@PathVariable int idPermiso, @PathVariable int idRol) {
        return RolApiController.resultado(permisoService.eliminarPermisoHasRol(idPermiso, idRol));
    }
}
