package com.latinburger.controller.api;

import com.latinburger.entity.TipoDocumento;
import com.latinburger.service.TipoDocumentoService;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/** Endpoints JSON de tipos de documento (TipoDocumentoDAO). Solo administradores. */
@RestController
@RequestMapping("/api/admin/tipos-documento")
public class TipoDocumentoApiController {

    private final TipoDocumentoService tipoDocumentoService;

    public TipoDocumentoApiController(TipoDocumentoService tipoDocumentoService) {
        this.tipoDocumentoService = tipoDocumentoService;
    }

    @GetMapping
    public List<TipoDocumento> listar() {
        return tipoDocumentoService.listar();
    }

    @GetMapping("/{id}")
    public ResponseEntity<TipoDocumento> consultar(@PathVariable int id) {
        TipoDocumento tipo = tipoDocumentoService.consultarTipoDocumento(id);
        return tipo != null ? ResponseEntity.ok(tipo) : ResponseEntity.notFound().build();
    }

    /** El id se envía en el cuerpo (la tabla no es AUTO_INCREMENT en el DAO original). */
    @PostMapping
    public ResponseEntity<Boolean> insertar(@RequestBody TipoDocumento tipo) {
        boolean ok = tipoDocumentoService.insertarTipoDocumento(tipo);
        return ok ? ResponseEntity.ok(true) : ResponseEntity.status(HttpStatus.CONFLICT).body(false);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Boolean> actualizar(@PathVariable int id, @RequestBody TipoDocumento tipo) {
        tipo.setIdTipoDocumento(id);
        return RolApiController.resultado(tipoDocumentoService.actualizarTipoDocumento(tipo));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Boolean> eliminar(@PathVariable int id) {
        return RolApiController.resultado(tipoDocumentoService.eliminarTipoDocumento(id));
    }
}
