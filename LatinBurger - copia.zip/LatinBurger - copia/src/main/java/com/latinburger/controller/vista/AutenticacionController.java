package com.latinburger.controller.vista;

import com.latinburger.config.SesionKeys;
import com.latinburger.entity.Usuario;
import com.latinburger.service.TipoDocumentoService;
import com.latinburger.service.UsuarioService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

/** Inicio de sesión, cierre de sesión y registro (antes LoginServlet, LogoutServlet y RegistroServlet). */
@Controller
public class AutenticacionController {

    private static final Logger log = LoggerFactory.getLogger(AutenticacionController.class);

    private final UsuarioService usuarioService;
    private final TipoDocumentoService tipoDocumentoService;

    public AutenticacionController(UsuarioService usuarioService, TipoDocumentoService tipoDocumentoService) {
        this.usuarioService = usuarioService;
        this.tipoDocumentoService = tipoDocumentoService;
    }

    // ------------------------------ Login ------------------------------

    @GetMapping("/LoginServlet")
    public String login() {
        return "cliente/Login";
    }

    @PostMapping("/LoginServlet")
    public String validarLogin(@RequestParam(value = "numDocumento", required = false) String numDocumento,
                               @RequestParam(value = "contrasena", required = false) String contrasena,
                               HttpServletRequest request, Model model) {
        Usuario usuario = usuarioService.validarUsuario(numDocumento != null ? numDocumento.trim() : null, contrasena);
        if (usuario == null) {
            model.addAttribute("error", "Número de documento o contraseña incorrectos.");
            return "cliente/Login";
        }
        if ("Inactivo".equalsIgnoreCase(usuario.getEstado())) {
            model.addAttribute("error", "Tu cuenta está inactiva. Comunícate con el administrador.");
            return "cliente/Login";
        }

        HttpSession session = request.getSession();
        // Se renueva el id de sesión al autenticarse (evita la fijación de sesión);
        // los atributos de la sesión se conservan.
        request.changeSessionId();
        session.setAttribute(SesionKeys.USUARIO_LOGUEADO, usuario);
        session.setAttribute(SesionKeys.NOMBRE_CLIENTE, usuario.getNombre());
        session.setAttribute(SesionKeys.ROL_ID, usuario.getRolIdRol());

        // rol_id_rol = 1 -> Administrador; el resto son roles de cliente/staff
        if (usuario.getRolIdRol() == SesionKeys.ROL_ADMINISTRADOR) {
            return "redirect:/AdminDashboardServlet";
        }
        return "redirect:/PanelClienteServlet";
    }

    // ------------------------------ Logout -----------------------------

    @GetMapping("/LogoutServlet")
    public String logout(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session != null) {
            session.invalidate();
        }
        return "redirect:/";
    }

    // ----------------------------- Registro ----------------------------

    @GetMapping("/RegistroServlet")
    public String registro(Model model) {
        model.addAttribute("listaTiposDocumento", tipoDocumentoService.listar());
        return "cliente/Registro";
    }

    @PostMapping("/RegistroServlet")
    public String registrar(@RequestParam(value = "nombre", required = false) String nombre,
                            @RequestParam(value = "apellido", required = false) String apellido,
                            @RequestParam(value = "tipo_documento_idtipo_documento", required = false) String tipoDocumentoId,
                            @RequestParam(value = "numero_documento", required = false) String numDocumento,
                            @RequestParam(value = "direccion", required = false) String direccion,
                            @RequestParam(value = "telefono", required = false) String telefono,
                            @RequestParam(value = "fecha_nacimiento", required = false) String fechaNacStr,
                            @RequestParam(value = "contrasena", required = false) String contrasena,
                            Model model) {
        if (vacio(nombre) || vacio(apellido) || vacio(tipoDocumentoId) || vacio(numDocumento)
                || vacio(direccion) || vacio(telefono) || vacio(fechaNacStr) || vacio(contrasena)) {
            model.addAttribute("error", "Todos los campos son obligatorios.");
            return registro(model);
        }
        if (contrasena.length() > 45) {
            model.addAttribute("error", "La contraseña no puede superar los 45 caracteres.");
            return registro(model);
        }
        try {
            LocalDate fechaNacimiento = LocalDate.parse(fechaNacStr);
            if (fechaNacimiento.isAfter(LocalDate.now())) {
                model.addAttribute("error", "La fecha de nacimiento no puede ser futura.");
                return registro(model);
            }
            if (usuarioService.existeDocumento(numDocumento)) {
                model.addAttribute("error", "Ya existe una cuenta registrada con ese número de documento.");
                return registro(model);
            }

            Usuario nuevoUsuario = new Usuario();
            nuevoUsuario.setNombre(nombre.trim());
            nuevoUsuario.setApellido(apellido.trim());
            nuevoUsuario.setTipoDocumentoIdTipoDocumento(Integer.parseInt(tipoDocumentoId.trim()));
            nuevoUsuario.setNumeroDocumento(numDocumento.trim());
            nuevoUsuario.setDireccion(direccion.trim());
            nuevoUsuario.setTelefono(telefono.trim());
            nuevoUsuario.setFechaNacimiento(fechaNacimiento);
            nuevoUsuario.setContrasena(contrasena);
            // Valores por defecto para nuevos usuarios
            nuevoUsuario.setRolIdRol(SesionKeys.ROL_CLIENTE);
            nuevoUsuario.setEstado("Activo");

            if (usuarioService.insertarUsuario(nuevoUsuario)) {
                return "redirect:/LoginServlet?registro=exito";
            }
            model.addAttribute("error", "No se pudo registrar el usuario. Verifica los datos e inténtalo de nuevo.");
        } catch (DateTimeParseException e) {
            model.addAttribute("error", "Formato de fecha inválido. Por favor selecciona una fecha correcta.");
        } catch (NumberFormatException e) {
            model.addAttribute("error", "Selecciona un tipo de documento válido.");
        } catch (RuntimeException e) {
            log.error("Error en registro POST: {}", e.getMessage(), e);
            model.addAttribute("error", "Error interno al procesar el registro. Inténtalo más tarde.");
        }
        return registro(model);
    }

    private static boolean vacio(String valor) {
        return valor == null || valor.trim().isEmpty();
    }
}
