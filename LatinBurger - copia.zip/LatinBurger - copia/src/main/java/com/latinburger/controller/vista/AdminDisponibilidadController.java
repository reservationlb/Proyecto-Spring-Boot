package com.latinburger.controller.vista;

import com.latinburger.entity.Disponibilidad;
import com.latinburger.service.DisponibilidadService;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

/** Gestión de horarios disponibles (antes AdminDisponibilidadServlet). */
@Controller
public class AdminDisponibilidadController {

    private final DisponibilidadService disponibilidadService;

    public AdminDisponibilidadController(DisponibilidadService disponibilidadService) {
        this.disponibilidadService = disponibilidadService;
    }

    @GetMapping("/AdminDisponibilidadServlet")
    public String listar(Model model) {
        cargar(model);
        return "administrador/Disponibilidad";
    }

    @PostMapping("/AdminDisponibilidadServlet")
    public String accion(@RequestParam(value = "accion", required = false) String accion,
                         @RequestParam(value = "fecha", required = false) String fecha,
                         @RequestParam(value = "hora", required = false) String horaStr,
                         @RequestParam(value = "idDisponibilidad", required = false) String idDisponibilidad,
                         Model model) {
        String error = null;
        if ("agregar".equals(accion)) {
            try {
                Disponibilidad nueva = new Disponibilidad();
                nueva.setFecha(LocalDate.parse(fecha));
                nueva.setHora(LocalTime.parse(horaStr.length() == 5 ? horaStr + ":00" : horaStr));
                nueva.setEstado(DisponibilidadService.DISPONIBLE);
                disponibilidadService.insertarDisponibilidad(nueva);
            } catch (DateTimeParseException | NullPointerException e) {
                error = "Fecha u hora inválida.";
            } catch (DataAccessException e) {
                error = "No se pudo agregar el horario. Intenta nuevamente.";
            }
        } else if ("eliminar".equals(accion)) {
            try {
                int id = Integer.parseInt(idDisponibilidad);
                if (!disponibilidadService.eliminarSiDisponible(id)) {
                    error = "Solo se pueden eliminar horarios que sigan 'Disponible' "
                            + "(uno ya ocupado pertenece a una reserva existente).";
                }
            } catch (NumberFormatException ignored) {
                // id inválido: se ignora, igual que en el Servlet original
            }
        }

        if (error != null) {
            model.addAttribute("error", error);
            cargar(model);
            return "administrador/Disponibilidad";
        }
        return "redirect:/AdminDisponibilidadServlet";
    }

    private void cargar(Model model) {
        model.addAttribute("disponibilidades", disponibilidadService.listarTodas());
        model.addAttribute("seccionActiva", "disponibilidad");
    }
}
