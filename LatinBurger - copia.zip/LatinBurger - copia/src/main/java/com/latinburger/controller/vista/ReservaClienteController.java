package com.latinburger.controller.vista;

import com.latinburger.config.AutenticacionInterceptor;
import com.latinburger.config.SesionKeys;
import com.latinburger.dto.ItemCarrito;
import com.latinburger.entity.Abono;
import com.latinburger.entity.Disponibilidad;
import com.latinburger.entity.Reserva;
import com.latinburger.entity.TipoDecoracion;
import com.latinburger.entity.TipoEvento;
import com.latinburger.entity.Usuario;
import com.latinburger.service.CarritoService;
import com.latinburger.service.CatalogoService;
import com.latinburger.service.DisponibilidadService;
import com.latinburger.service.ProductoService;
import com.latinburger.service.ReservaService;
import com.latinburger.service.TipoMenuService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

/**
 * Asistente de reserva del cliente:
 * Disponibilidad -> Tipo de evento -> Decoración -> Color -> Menú -> Resumen -> Factura.
 * (antes ReservarServlet, DisponibilidadServlet, EventoServlet, DecoracionServlet,
 * ColorServlet, MenuServlet y ResumenServlet). Los datos de cada paso se guardan en
 * la sesión con los mismos nombres de atributo que usaba la versión con Servlets.
 * La verificación de sesión iniciada la hace {@link AutenticacionInterceptor}.
 */
@Controller
public class ReservaClienteController {

    private static final Logger log = LoggerFactory.getLogger(ReservaClienteController.class);

    private static final String MSG_CARRITO_VACIO =
            "Tu pedido está vacío. Agrega al menos un plato antes de continuar.";

    private final DisponibilidadService disponibilidadService;
    private final CatalogoService catalogoService;
    private final ProductoService productoService;
    private final CarritoService carritoService;
    private final TipoMenuService tipoMenuService;
    private final ReservaService reservaService;

    public ReservaClienteController(DisponibilidadService disponibilidadService, CatalogoService catalogoService,
                                    ProductoService productoService, CarritoService carritoService,
                                    TipoMenuService tipoMenuService, ReservaService reservaService) {
        this.disponibilidadService = disponibilidadService;
        this.catalogoService = catalogoService;
        this.productoService = productoService;
        this.carritoService = carritoService;
        this.tipoMenuService = tipoMenuService;
        this.reservaService = reservaService;
    }

    // ------------------------------ /Reservar ------------------------------

    /** Botón "RESERVAR": con sesión va a Disponibilidad, sin sesión al Login. */
    @GetMapping("/Reservar")
    public String reservar(HttpServletRequest request) {
        return AutenticacionInterceptor.haySesion(request) ? "redirect:/DisponibilidadServlet" : "redirect:/LoginServlet";
    }

    // --------------------------- 1. Disponibilidad --------------------------

    @GetMapping("/DisponibilidadServlet")
    public String disponibilidad(Model model) {
        cargarProximasFechas(model, null);
        return "cliente/Disponibilidad";
    }

    @PostMapping("/DisponibilidadServlet")
    public String disponibilidadPost(@RequestParam(value = "accion", required = false) String accion,
                                     @RequestParam(value = "fecha", required = false) String fechaStr,
                                     @RequestParam(value = "hora", required = false) String horaStr,
                                     HttpSession session, Model model) {
        if ("consultar".equals(accion)) {
            LocalDate fechaFiltro = null;
            if (fechaStr != null && !fechaStr.trim().isEmpty()) {
                try {
                    fechaFiltro = LocalDate.parse(fechaStr);
                } catch (DateTimeParseException e) {
                    model.addAttribute("mensajeErrorBD", "Fecha inválida.");
                }
            }
            cargarProximasFechas(model, fechaFiltro);
            return "cliente/Disponibilidad";
        }

        // Acción "Siguiente": valida que ese horario exista y siga Disponible
        try {
            LocalDate fecha = LocalDate.parse(fechaStr);
            LocalTime hora = LocalTime.parse(horaStr.length() == 5 ? horaStr + ":00" : horaStr);
            Disponibilidad disp = disponibilidadService.consultarPorFechaYHora(fecha, hora);
            if (disp == null) {
                model.addAttribute("mensajeErrorBD",
                        "Ese horario ya no está disponible. Por favor selecciona otro de la lista.");
                cargarProximasFechas(model, null);
                return "cliente/Disponibilidad";
            }
            session.setAttribute(SesionKeys.RESERVA_FECHA, fechaStr);
            session.setAttribute(SesionKeys.RESERVA_HORA, horaStr);
            session.setAttribute(SesionKeys.RESERVA_ID_DISPONIBILIDAD, disp.getIdDisponibilidad());
            return "redirect:/EventoServlet";
        } catch (DateTimeParseException | NullPointerException e) {
            model.addAttribute("mensajeErrorBD", "Fecha u hora inválida.");
            cargarProximasFechas(model, null);
            return "cliente/Disponibilidad";
        }
    }

    private void cargarProximasFechas(Model model, LocalDate fechaFiltro) {
        List<Disponibilidad> lista = disponibilidadService.listarDisponibles(fechaFiltro);
        model.addAttribute("proximasFechas", disponibilidadService.convertirAMapa(lista));
    }

    // --------------------------- 2. Tipo de evento --------------------------

    @GetMapping("/EventoServlet")
    public String evento(HttpSession session, Model model) {
        if (session.getAttribute(SesionKeys.RESERVA_ID_DISPONIBILIDAD) == null) {
            return "redirect:/DisponibilidadServlet";
        }
        model.addAttribute("listaEventos", catalogoService.listarEventos());
        return "cliente/Evento";
    }

    @PostMapping("/EventoServlet")
    public String eventoPost(@RequestParam(value = "idTipoEvento", required = false) String idTipoEventoStr,
                             @RequestParam(value = "numeroPersonas", required = false) String numeroPersonasStr,
                             HttpSession session, Model model) {
        try {
            int idTipoEvento = Integer.parseInt(idTipoEventoStr);
            int numeroPersonas = Integer.parseInt(numeroPersonasStr);
            if (numeroPersonas <= 0) {
                throw new IllegalArgumentException("El número de personas debe ser mayor a cero.");
            }
            session.setAttribute(SesionKeys.RESERVA_ID_TIPO_EVENTO, idTipoEvento);
            session.setAttribute(SesionKeys.RESERVA_NUMERO_PERSONAS, numeroPersonas);
            return "redirect:/DecoracionServlet";
        } catch (IllegalArgumentException e) {
            model.addAttribute("error", "Selecciona un tipo de evento e indica un número de personas válido.");
            model.addAttribute("listaEventos", catalogoService.listarEventos());
            return "cliente/Evento";
        }
    }

    // ----------------------------- 3. Decoración ----------------------------

    @GetMapping("/DecoracionServlet")
    public String decoracion(HttpSession session, Model model) {
        if (session.getAttribute(SesionKeys.RESERVA_ID_TIPO_EVENTO) == null) {
            return "redirect:/EventoServlet";
        }
        model.addAttribute("listaDecoraciones", catalogoService.listarDecoraciones());
        return "cliente/Decoracion";
    }

    @PostMapping("/DecoracionServlet")
    public String decoracionPost(@RequestParam(value = "idTipoDecoracion", required = false) String idTipoDecoracionStr,
                                 HttpSession session, Model model) {
        try {
            int idTipoDecoracion = Integer.parseInt(idTipoDecoracionStr);
            session.setAttribute(SesionKeys.RESERVA_ID_TIPO_DECORACION, idTipoDecoracion);
            return "redirect:/ColorServlet";
        } catch (NumberFormatException e) {
            model.addAttribute("error", "Selecciona una decoración para continuar.");
            model.addAttribute("listaDecoraciones", catalogoService.listarDecoraciones());
            return "cliente/Decoracion";
        }
    }

    // -------------------------------- 4. Color ------------------------------

    @GetMapping("/ColorServlet")
    public String color(HttpSession session, Model model) {
        if (session.getAttribute(SesionKeys.RESERVA_ID_TIPO_DECORACION) == null) {
            return "redirect:/DecoracionServlet";
        }
        model.addAttribute("listaColores", catalogoService.listarColores());
        return "cliente/Color";
    }

    @PostMapping("/ColorServlet")
    public String colorPost(@RequestParam(value = "color", required = false) String color,
                            @RequestParam(value = "comentarios", required = false) String comentarios,
                            HttpSession session, Model model) {
        if (color == null || color.trim().isEmpty()) {
            model.addAttribute("error", "Selecciona un color para el evento.");
            model.addAttribute("listaColores", catalogoService.listarColores());
            return "cliente/Color";
        }
        session.setAttribute(SesionKeys.RESERVA_COLOR, color);
        session.setAttribute(SesionKeys.RESERVA_COMENTARIOS, comentarios != null ? comentarios : "");
        return "redirect:/MenuServlet";
    }

    // -------------------------------- 5. Menú -------------------------------

    @GetMapping("/MenuServlet")
    public String menu(HttpSession session, Model model) {
        if (session.getAttribute(SesionKeys.RESERVA_COLOR) == null) {
            // Todavía no completó los pasos previos del asistente
            return "redirect:/DisponibilidadServlet";
        }
        cargarMenu(model);
        return "cliente/Menu";
    }

    @PostMapping("/MenuServlet")
    public String menuPost(@RequestParam(value = "carritoData", required = false) String carritoData,
                           HttpSession session, Model model) {
        // Se vuelven a consultar los precios oficiales en la BD (no se confía en el navegador)
        List<ItemCarrito> carrito = carritoService.parsearCarritoCliente(carritoData);
        if (carrito.isEmpty()) {
            model.addAttribute("errorMenu", MSG_CARRITO_VACIO);
            cargarMenu(model);
            return "cliente/Menu";
        }
        session.setAttribute(SesionKeys.CARRITO_PRODUCTOS, new ArrayList<>(carrito));
        return "redirect:/ResumenServlet";
    }

    private void cargarMenu(Model model) {
        model.addAttribute("listaMenu", productoService.obtenerListaMenu());
        List<Map<String, String>> listaCategorias = new ArrayList<>();
        catalogoService.listarCategoriasOrdenadas().forEach(c -> {
            Map<String, String> categoria = new HashMap<>();
            categoria.put("id", String.valueOf(c.getIdCategoria()));
            categoria.put("nombre", c.getNombre());
            listaCategorias.add(categoria);
        });
        model.addAttribute("listaCategorias", listaCategorias);
    }

    // ------------------------------- 6. Resumen -----------------------------

    @GetMapping("/ResumenServlet")
    public String resumen(HttpSession session, Model model) {
        List<ItemCarrito> carrito = carrito(session);
        if (carrito == null || carrito.isEmpty()) {
            return "redirect:/MenuServlet";
        }
        Integer idTipoEvento = (Integer) session.getAttribute(SesionKeys.RESERVA_ID_TIPO_EVENTO);
        Integer idTipoDecoracion = (Integer) session.getAttribute(SesionKeys.RESERVA_ID_TIPO_DECORACION);
        if (idTipoEvento == null || idTipoDecoracion == null) {
            return "redirect:/DisponibilidadServlet";
        }
        cargarResumen(session, model, carrito, idTipoEvento, idTipoDecoracion);
        return "cliente/Resumen";
    }

    private void cargarResumen(HttpSession session, Model model, List<ItemCarrito> carrito,
                               int idTipoEvento, int idTipoDecoracion) {
        TipoEvento evento = catalogoService.consultarTipoEvento(idTipoEvento);
        TipoDecoracion decoracion = catalogoService.consultarTipoDecoracion(idTipoDecoracion);
        BigDecimal totalPlatos = carritoService.totalCarrito(carrito);

        model.addAttribute("carrito", carrito);
        model.addAttribute("evento", evento);
        model.addAttribute("decoracion", decoracion);
        model.addAttribute("totalPlatos", totalPlatos);
        model.addAttribute("totalGeneral", reservaService.calcularTotal(evento, decoracion, totalPlatos));
        model.addAttribute("reservaFecha", session.getAttribute(SesionKeys.RESERVA_FECHA));
        model.addAttribute("reservaHora", session.getAttribute(SesionKeys.RESERVA_HORA));
        model.addAttribute("reservaNumeroPersonas", session.getAttribute(SesionKeys.RESERVA_NUMERO_PERSONAS));
        model.addAttribute("reservaColor", session.getAttribute(SesionKeys.RESERVA_COLOR));
        model.addAttribute("reservaComentarios", session.getAttribute(SesionKeys.RESERVA_COMENTARIOS));
    }

    @PostMapping("/ResumenServlet")
    public String confirmar(@RequestParam(value = "metodoPago", required = false) String metodoPago,
                            @RequestParam(value = "montoAbono", required = false) String montoAbonoStr,
                            HttpSession session, Model model, RedirectAttributes redirect) {
        List<ItemCarrito> carrito = carrito(session);
        Integer idDisponibilidad = (Integer) session.getAttribute(SesionKeys.RESERVA_ID_DISPONIBILIDAD);
        Integer idTipoEvento = (Integer) session.getAttribute(SesionKeys.RESERVA_ID_TIPO_EVENTO);
        Integer idTipoDecoracion = (Integer) session.getAttribute(SesionKeys.RESERVA_ID_TIPO_DECORACION);
        String fechaStr = (String) session.getAttribute(SesionKeys.RESERVA_FECHA);
        String horaStr = (String) session.getAttribute(SesionKeys.RESERVA_HORA);
        Integer numeroPersonas = (Integer) session.getAttribute(SesionKeys.RESERVA_NUMERO_PERSONAS);
        String color = (String) session.getAttribute(SesionKeys.RESERVA_COLOR);
        String comentarios = (String) session.getAttribute(SesionKeys.RESERVA_COMENTARIOS);
        Usuario usuario = (Usuario) session.getAttribute(SesionKeys.USUARIO_LOGUEADO);

        if (carrito == null || carrito.isEmpty() || idDisponibilidad == null || idTipoEvento == null
                || idTipoDecoracion == null || fechaStr == null || horaStr == null) {
            return "redirect:/DisponibilidadServlet";
        }

        TipoEvento evento = catalogoService.consultarTipoEvento(idTipoEvento);
        TipoDecoracion decoracion = catalogoService.consultarTipoDecoracion(idTipoDecoracion);
        BigDecimal totalGeneral = reservaService.calcularTotal(evento, decoracion, carritoService.totalCarrito(carrito));

        Reserva reserva = new Reserva();
        reserva.setFecha(LocalDate.parse(fechaStr));
        reserva.setHora(LocalTime.parse(horaStr.length() == 5 ? horaStr + ":00" : horaStr));
        reserva.setNumeroPersona(numeroPersonas != null ? numeroPersonas : 1);
        reserva.setValorReserva(totalGeneral);
        reserva.setDisponibilidadIdDisponibilidad(idDisponibilidad);
        reserva.setTipoMenuIdTipoMenu(tipoMenuService.idMenuParaReserva());
        reserva.setTipoDecoracionIdTipoDecoracion(idTipoDecoracion);
        reserva.setTipoEventoIdTipoEvento(idTipoEvento);
        reserva.setUsuarioIdUsuario(usuario.getIdUsuario());
        reserva.setColorEvento(color);
        reserva.setComentarios(comentarios);

        Abono abono = null;
        if (metodoPago != null && !metodoPago.trim().isEmpty()) {
            BigDecimal montoAbono;
            try {
                montoAbono = (montoAbonoStr != null && !montoAbonoStr.trim().isEmpty())
                        ? new BigDecimal(montoAbonoStr) : totalGeneral;
            } catch (NumberFormatException e) {
                montoAbono = totalGeneral;
            }
            abono = new Abono();
            abono.setMedioPago(metodoPago);
            abono.setValorAbono(montoAbono);
            abono.setEstado("Registrado");
        }

        int idReservaGenerado;
        try {
            idReservaGenerado = reservaService.insertarReservaCompleta(reserva, carritoService.aDetalle(carrito), abono);
        } catch (RuntimeException e) {
            log.error("Error al confirmar la reserva: {}", e.getMessage(), e);
            idReservaGenerado = ReservaService.ERROR_INESPERADO;
        }

        if (idReservaGenerado == ReservaService.HORARIO_NO_DISPONIBLE) {
            redirect.addFlashAttribute("mensajeErrorBD",
                    "Justo acaban de reservar ese horario. Por favor elige otra fecha u hora disponible.");
            return "redirect:/DisponibilidadServlet";
        } else if (idReservaGenerado < 0) {
            model.addAttribute("error", "Ocurrió un error al confirmar tu reserva. Intenta nuevamente.");
            cargarResumen(session, model, carrito, idTipoEvento, idTipoDecoracion);
            return "cliente/Resumen";
        }

        // Reserva confirmada: se limpia el asistente de la sesión
        session.removeAttribute(SesionKeys.RESERVA_FECHA);
        session.removeAttribute(SesionKeys.RESERVA_HORA);
        session.removeAttribute(SesionKeys.RESERVA_ID_DISPONIBILIDAD);
        session.removeAttribute(SesionKeys.RESERVA_ID_TIPO_EVENTO);
        session.removeAttribute(SesionKeys.RESERVA_NUMERO_PERSONAS);
        session.removeAttribute(SesionKeys.RESERVA_ID_TIPO_DECORACION);
        session.removeAttribute(SesionKeys.RESERVA_COLOR);
        session.removeAttribute(SesionKeys.RESERVA_COMENTARIOS);
        session.removeAttribute(SesionKeys.CARRITO_PRODUCTOS);
        session.setAttribute(SesionKeys.ULTIMA_RESERVA_ID, idReservaGenerado);
        return "redirect:/FacturaServlet?id=" + idReservaGenerado;
    }

    @SuppressWarnings("unchecked")
    private static List<ItemCarrito> carrito(HttpSession session) {
        return (List<ItemCarrito>) session.getAttribute(SesionKeys.CARRITO_PRODUCTOS);
    }
}
