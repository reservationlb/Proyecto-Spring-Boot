package com.latinburger.controller.vista;

import com.latinburger.service.CatalogoService;
import com.latinburger.service.ProductoService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/** Página de inicio pública (antes InicioServlet, mapeado a "", "/Inicio" y "/InicioServlet"). */
@Controller
public class InicioController {

    private static final Logger log = LoggerFactory.getLogger(InicioController.class);

    private final ProductoService productoService;
    private final CatalogoService catalogoService;

    public InicioController(ProductoService productoService, CatalogoService catalogoService) {
        this.productoService = productoService;
        this.catalogoService = catalogoService;
    }

    @RequestMapping(value = {"/", "/Inicio", "/InicioServlet"}, method = {RequestMethod.GET, RequestMethod.POST})
    public String inicio(Model model) {
        try {
            model.addAttribute("listaProductos", productoService.listar());
            model.addAttribute("listaCategorias", catalogoService.listarCategorias());
        } catch (RuntimeException e) {
            log.error("Error al cargar los datos en Inicio: {}", e.getMessage(), e);
        }
        // Valores por defecto que usaba Inicio.jsp cuando no había datos de Google Maps
        model.addAttribute("ratingReal", "4.8");
        model.addAttribute("totalResenas", "150");
        return "cliente/Inicio";
    }
}
