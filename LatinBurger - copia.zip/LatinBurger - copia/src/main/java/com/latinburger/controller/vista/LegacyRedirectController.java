package com.latinburger.controller.vista;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * Las JSP ya no existen: estas rutas antiguas (enlaces guardados, marcadores, welcome-file de
 * web.xml) redirigen a su controlador equivalente para no romper la navegación existente.
 */
@Controller
public class LegacyRedirectController {

    @GetMapping({"/Index.jsp", "/View/Cliente/Inicio.jsp"})
    public String inicio() {
        return "redirect:/";
    }

    @GetMapping("/View/Cliente/Login.jsp")
    public String login() {
        return "redirect:/LoginServlet";
    }

    @GetMapping("/View/Cliente/Registro.jsp")
    public String registro() {
        return "redirect:/RegistroServlet";
    }
}
