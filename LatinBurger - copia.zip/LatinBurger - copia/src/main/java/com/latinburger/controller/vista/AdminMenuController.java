package com.latinburger.controller.vista;

import com.latinburger.entity.Producto;
import com.latinburger.service.CatalogoService;
import com.latinburger.service.ProductoService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

/** Gestión de platos del menú (antes AdminMenuServlet y AdminMenuFormServlet). */
@Controller
public class AdminMenuController {

    private final ProductoService productoService;
    private final CatalogoService catalogoService;

    public AdminMenuController(ProductoService productoService, CatalogoService catalogoService) {
        this.productoService = productoService;
        this.catalogoService = catalogoService;
    }

    @GetMapping("/AdminMenuServlet")
    public String listar(Model model) {
        model.addAttribute("productos", productoService.listarTodos());
        model.addAttribute("categorias", catalogoService.listarCategorias());
        model.addAttribute("nombresCategoria", catalogoService.nombresCategoria());
        model.addAttribute("seccionActiva", "menu");
        return "administrador/Menu";
    }

    /** Ocultar / mostrar un plato (no se elimina físicamente). */
    @PostMapping("/AdminMenuServlet")
    public String cambiarActivo(@RequestParam(value = "accion", required = false) String accion,
                                @RequestParam(value = "idProducto", required = false) String idProductoStr) {
        try {
            int idProducto = Integer.parseInt(idProductoStr);
            if ("ocultar".equals(accion)) {
                productoService.cambiarActivo(idProducto, false);
            } else if ("mostrar".equals(accion)) {
                productoService.cambiarActivo(idProducto, true);
            }
        } catch (NumberFormatException ignored) {
            // id inválido: se ignora, igual que en el Servlet original
        }
        return "redirect:/AdminMenuServlet";
    }

    @GetMapping("/AdminMenuFormServlet")
    public String formulario(@RequestParam(value = "id", required = false) String idStr, Model model) {
        Producto producto = null;
        if (idStr != null) {
            try {
                producto = productoService.consultar(Integer.parseInt(idStr));
            } catch (NumberFormatException ignored) {
                // se muestra el formulario vacío (nuevo plato)
            }
        }
        model.addAttribute("producto", producto);
        model.addAttribute("categorias", catalogoService.listarCategorias());
        model.addAttribute("seccionActiva", "menu");
        return "administrador/MenuForm";
    }

    @PostMapping("/AdminMenuFormServlet")
    public String guardar(@RequestParam(value = "idProducto", required = false) String idStr,
                          @RequestParam(value = "nombre", required = false) String nombre,
                          @RequestParam(value = "descripcion", required = false) String descripcion,
                          @RequestParam(value = "precio", required = false) String precio,
                          @RequestParam(value = "idCategoria", required = false) String idCategoria,
                          @RequestParam(value = "imagen", required = false) String imagen,
                          Model model) {
        try {
            Producto p = new Producto();
            p.setNombre(nombre);
            p.setDescripcion(descripcion);
            p.setPrecio(Double.parseDouble(precio));
            p.setIdCategoria(Integer.parseInt(idCategoria));
            p.setImagen(imagen);
            if (idStr != null && !idStr.trim().isEmpty() && !"0".equals(idStr)) {
                p.setIdProducto(Integer.parseInt(idStr));
            }
            productoService.guardar(p);
            return "redirect:/AdminMenuServlet";
        } catch (NumberFormatException | NullPointerException e) {
            model.addAttribute("error", "Revisa que el precio y la categoría sean válidos.");
            model.addAttribute("categorias", catalogoService.listarCategorias());
            model.addAttribute("seccionActiva", "menu");
            return "administrador/MenuForm";
        }
    }
}
