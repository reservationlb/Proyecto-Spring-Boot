package com.latinburger.controller.vista;

import com.latinburger.config.SesionKeys;
import com.latinburger.entity.Disponibilidad;
import com.latinburger.entity.Reserva;
import com.latinburger.entity.ReservaProducto;
import com.latinburger.entity.TipoDecoracion;
import com.latinburger.entity.TipoEvento;
import com.latinburger.entity.Usuario;
import com.latinburger.service.CarritoService;
import com.latinburger.service.CatalogoService;
import com.latinburger.service.DisponibilidadService;
import com.latinburger.service.ProductoService;
import com.latinburger.service.ReservaService;
import com.latinburger.service.TipoDocumentoService;
import com.latinburger.service.TipoMenuService;
import com.latinburger.service.UsuarioService;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

/** Gestión de reservas y registro de pedidos por el administrador (antes AdminReservasServlet y AdminReservaFormServlet). */
@Controller
public class AdminReservasController {

    private static final Logger log = LoggerFactory.getLogger(AdminReservasController.class);

    /** Estados posibles de una reserva (selector de Reservas.jsp). */
    private static final List<String> ESTADOS =
            Arrays.asList("Pendiente", "Confirmada", "En preparación", "Entregada", "Cancelada");

    private final ReservaService reservaService;
    private final DisponibilidadService disponibilidadService;
    private final CatalogoService catalogoService;
    private final TipoDocumentoService tipoDocumentoService;
    private final TipoMenuService tipoMenuService;
    private final ProductoService productoService;
    private final UsuarioService usuarioService;
    private final CarritoService carritoService;

    public AdminReservasController(ReservaService reservaService, DisponibilidadService disponibilidadService,
                                   CatalogoService catalogoService, TipoDocumentoService tipoDocumentoService,
                                   TipoMenuService tipoMenuService, ProductoService productoService,
                                   UsuarioService usuarioService, CarritoService carritoService) {
        this.reservaService = reservaService;
        this.disponibilidadService = disponibilidadService;
        this.catalogoService = catalogoService;
        this.tipoDocumentoService = tipoDocumentoService;
        this.tipoMenuService = tipoMenuService;
        this.productoService = productoService;
        this.usuarioService = usuarioService;
        this.carritoService = carritoService;
    }

    // ------------------------------ Reservas ------------------------------

    @GetMapping("/AdminReservasServlet")
    public String listar(Model model) {
        model.addAttribute("reservas", reservaService.listarTodasConDetalle());
        model.addAttribute("estados", ESTADOS);
        model.addAttribute("seccionActiva", "reservas");
        return "administrador/Reservas";
    }

    /** Cambiar estado o cancelar (cancelar libera el horario). */
    @PostMapping("/AdminReservasServlet")
    public String accion(@RequestParam(value = "accion", required = false) String accion,
                         @RequestParam(value = "idReserva", required = false) String idStr,
                         @RequestParam(value = "nuevoEstado", required = false) String nuevoEstado) {
        try {
            int idReserva = Integer.parseInt(idStr);
            if ("cambiarEstado".equals(accion)) {
                reservaService.actualizarEstado(idReserva, nuevoEstado);
            } else if ("cancelar".equals(accion)) {
                reservaService.cancelarReserva(idReserva);
            }
        } catch (NumberFormatException ignored) {
            // id inválido: se ignora, igual que en el Servlet original
        }
        return "redirect:/AdminReservasServlet";
    }

    // ---------------------------- Nuevo pedido ----------------------------

    @GetMapping("/AdminReservaFormServlet")
    public String formulario(Model model) {
        cargarCatalogos(model);
        return "administrador/ReservaForm";
    }

    @PostMapping("/AdminReservaFormServlet")
    public String registrar(@RequestParam(value = "numeroDocumento", required = false) String numeroDocumento,
                            @RequestParam(value = "nombre", required = false) String nombre,
                            @RequestParam(value = "apellido", required = false) String apellido,
                            @RequestParam(value = "tipoDocumentoId", required = false) String tipoDocumentoId,
                            @RequestParam(value = "direccion", required = false) String direccion,
                            @RequestParam(value = "telefono", required = false) String telefono,
                            @RequestParam(value = "idDisponibilidad", required = false) String idDisponibilidadStr,
                            @RequestParam(value = "idTipoEvento", required = false) String idTipoEventoStr,
                            @RequestParam(value = "idTipoDecoracion", required = false) String idTipoDecoracionStr,
                            @RequestParam(value = "numeroPersonas", required = false) String numeroPersonasStr,
                            @RequestParam(value = "color", required = false) String color,
                            @RequestParam(value = "comentarios", required = false) String comentarios,
                            @RequestParam(value = "carritoData", required = false) String carritoData,
                            Model model) {
        try {
            // 1. Cliente: si el documento ya existe se reutiliza; si no, se crea (contraseña = documento)
            Usuario cliente = usuarioService.consultarUsuario(numeroDocumento);
            if (cliente == null) {
                cliente = new Usuario();
                cliente.setNombre(nombre);
                cliente.setApellido(apellido);
                cliente.setTipoDocumentoIdTipoDocumento(Integer.parseInt(tipoDocumentoId));
                cliente.setNumeroDocumento(numeroDocumento);
                cliente.setDireccion(direccion);
                cliente.setTelefono(telefono);
                cliente.setFechaNacimiento(LocalDate.of(2000, 1, 1));
                cliente.setContrasena(numeroDocumento);
                cliente.setRolIdRol(SesionKeys.ROL_CLIENTE);
                cliente.setEstado("Activo");
                usuarioService.insertarUsuario(cliente);
                cliente = usuarioService.consultarUsuario(numeroDocumento);
            }

            int idDisponibilidad = Integer.parseInt(idDisponibilidadStr);
            int idTipoEvento = Integer.parseInt(idTipoEventoStr);
            int idTipoDecoracion = Integer.parseInt(idTipoDecoracionStr);
            int numeroPersonas = Integer.parseInt(numeroPersonasStr);

            TipoEvento evento = catalogoService.consultarTipoEvento(idTipoEvento);
            TipoDecoracion decoracion = catalogoService.consultarTipoDecoracion(idTipoDecoracion);

            // 2. Platos del pedido con el precio oficial de la base de datos
            List<ReservaProducto> items = carritoService.parsearCarritoAdmin(carritoData);

            Reserva reserva = new Reserva();
            Disponibilidad disp = buscarDisponible(idDisponibilidad);
            reserva.setFecha(disp != null ? disp.getFecha() : null);
            reserva.setHora(disp != null ? disp.getHora() : null);
            reserva.setNumeroPersona(numeroPersonas);
            reserva.setValorReserva(reservaService.calcularTotal(evento, decoracion, carritoService.totalDetalle(items)));
            reserva.setDisponibilidadIdDisponibilidad(idDisponibilidad);
            reserva.setTipoMenuIdTipoMenu(tipoMenuService.idMenuParaReserva());
            reserva.setTipoDecoracionIdTipoDecoracion(idTipoDecoracion);
            reserva.setTipoEventoIdTipoEvento(idTipoEvento);
            reserva.setUsuarioIdUsuario(cliente.getIdUsuario());
            reserva.setColorEvento(color);
            reserva.setComentarios(comentarios);

            int idGenerado;
            if (disp == null) {
                idGenerado = ReservaService.HORARIO_NO_DISPONIBLE;
            } else {
                try {
                    idGenerado = reservaService.insertarReservaCompleta(reserva, items, null);
                } catch (RuntimeException e) {
                    log.error("Error al registrar el pedido del administrador: {}", e.getMessage(), e);
                    idGenerado = ReservaService.ERROR_INESPERADO;
                }
            }

            if (idGenerado == ReservaService.HORARIO_NO_DISPONIBLE) {
                return volverAlFormulario(model, "Ese horario ya fue tomado. Elige otra disponibilidad.");
            } else if (idGenerado < 0) {
                return volverAlFormulario(model, "Ocurrió un error al registrar el pedido. Intenta nuevamente.");
            }
            return "redirect:/FacturaServlet?id=" + idGenerado;
        } catch (NumberFormatException | NullPointerException e) {
            return volverAlFormulario(model, "Revisa que todos los campos obligatorios estén completos.");
        }
    }

    /** Equivale a obtenerFechaDeId / obtenerHoraDeId: solo horarios que siguen disponibles. */
    private Disponibilidad buscarDisponible(int idDisponibilidad) {
        for (Disponibilidad d : disponibilidadService.listarDisponibles(null)) {
            if (d.getIdDisponibilidad() == idDisponibilidad) {
                return d;
            }
        }
        return null;
    }

    private String volverAlFormulario(Model model, String error) {
        model.addAttribute("error", error);
        cargarCatalogos(model);
        return "administrador/ReservaForm";
    }

    private void cargarCatalogos(Model model) {
        model.addAttribute("disponibles", disponibilidadService.listarDisponibles(null));
        model.addAttribute("eventos", catalogoService.listarEventos());
        model.addAttribute("decoraciones", catalogoService.listarDecoraciones());
        model.addAttribute("tiposDocumento", tipoDocumentoService.listar());
        model.addAttribute("categorias", catalogoService.listarCategorias());
        model.addAttribute("nombresCategoria", catalogoService.nombresCategoria());
        model.addAttribute("productos", productoService.listar());
        model.addAttribute("colores", catalogoService.listarColores());
        model.addAttribute("seccionActiva", "reservas");
    }
}
