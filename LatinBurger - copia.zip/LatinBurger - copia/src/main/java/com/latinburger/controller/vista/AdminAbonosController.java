package com.latinburger.controller.vista;

import com.latinburger.service.AbonoService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

/** Listado de abonos del administrador (antes AdminAbonosServlet). */
@Controller
public class AdminAbonosController {

    private final AbonoService abonoService;

    public AdminAbonosController(AbonoService abonoService) {
        this.abonoService = abonoService;
    }

    @GetMapping("/AdminAbonosServlet")
    public String abonos(Model model) {
        model.addAttribute("abonos", abonoService.listarTodos());
        model.addAttribute("seccionActiva", "abonos");
        return "administrador/Abonos";
    }
}
