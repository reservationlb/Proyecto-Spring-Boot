package com.latinburger.controller.vista;

import com.latinburger.entity.Color;
import com.latinburger.entity.TipoDecoracion;
import com.latinburger.entity.TipoEvento;
import com.latinburger.service.CatalogoService;
import java.math.BigDecimal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * Catálogos administrables: tipos de evento, decoraciones y colores (antes AdminCatalogosServlet).
 * Parámetro "tipo": evento | decoracion | color.
 */
@Controller
public class AdminCatalogosController {

    private final CatalogoService catalogoService;

    public AdminCatalogosController(CatalogoService catalogoService) {
        this.catalogoService = catalogoService;
    }

    @GetMapping("/AdminCatalogosServlet")
    public String listar(@RequestParam(value = "tipo", required = false) String tipo,
                         @RequestParam(value = "editar", required = false) String editarStr,
                         Model model) {
        if (tipo == null || tipo.trim().isEmpty()) {
            tipo = "evento";
        }
        cargarDatos(model, tipo);

        if (editarStr != null) {
            try {
                int id = Integer.parseInt(editarStr);
                switch (tipo) {
                    case "evento":
                        model.addAttribute("eventoEditar", catalogoService.consultarTipoEvento(id));
                        break;
                    case "decoracion":
                        model.addAttribute("decoracionEditar", catalogoService.consultarTipoDecoracion(id));
                        break;
                    case "color":
                        model.addAttribute("colorEditar", catalogoService.consultarColor(id));
                        break;
                    default:
                        break;
                }
            } catch (NumberFormatException ignored) {
                // id inválido: se muestra el formulario de alta
            }
        }
        return "administrador/Catalogos";
    }

    @PostMapping("/AdminCatalogosServlet")
    public String accion(@RequestParam(value = "tipo", required = false) String tipo,
                         @RequestParam(value = "accion", required = false) String accion,
                         @RequestParam(value = "id", required = false) String idStr,
                         @RequestParam(value = "activo", required = false) String activo,
                         @RequestParam(value = "nombre", required = false) String nombre,
                         @RequestParam(value = "descripcion", required = false) String descripcion,
                         @RequestParam(value = "valor", required = false) String valor,
                         @RequestParam(value = "codigoHex", required = false) String codigoHex,
                         @RequestParam(value = "imagen", required = false) String imagen,
                         Model model) {
        String tipoSeguro = tipo != null ? tipo : "evento";
        try {
            if ("guardar".equals(accion)) {
                guardar(tipoSeguro, idStr, nombre, descripcion, valor, codigoHex, imagen);
            } else if ("cambiarActivo".equals(accion)) {
                int id = Integer.parseInt(idStr);
                boolean nuevoEstado = "1".equals(activo);
                switch (tipoSeguro) {
                    case "evento":
                        catalogoService.cambiarActivoEvento(id, nuevoEstado);
                        break;
                    case "decoracion":
                        catalogoService.cambiarActivoDecoracion(id, nuevoEstado);
                        break;
                    case "color":
                        catalogoService.cambiarActivoColor(id, nuevoEstado);
                        break;
                    default:
                        break;
                }
            }
            return "redirect:/AdminCatalogosServlet?tipo=" + tipoSeguro;
        } catch (NumberFormatException | NullPointerException e) {
            model.addAttribute("error", "Revisa que los valores numéricos sean correctos.");
            cargarDatos(model, tipoSeguro);
            return "administrador/Catalogos";
        }
    }

    private void guardar(String tipo, String idStr, String nombre, String descripcion, String valor,
                         String codigoHex, String imagen) {
        boolean esNuevo = (idStr == null || idStr.trim().isEmpty() || "0".equals(idStr));
        switch (tipo) {
            case "evento": {
                TipoEvento te = new TipoEvento();
                te.setNombreEvento(nombre);
                te.setDescripcion(descripcion);
                te.setValorEvento(new BigDecimal(valor));
                te.setImagen(imagen);
                te.setIdTipoEvento(esNuevo ? 0 : Integer.parseInt(idStr));
                catalogoService.guardarTipoEvento(te);
                break;
            }
            case "decoracion": {
                TipoDecoracion td = new TipoDecoracion();
                td.setNombreDecoracion(nombre);
                td.setDescripcion(descripcion);
                td.setValorDecoracion(new BigDecimal(valor));
                td.setImagen(imagen);
                td.setIdTipoDecoracion(esNuevo ? 0 : Integer.parseInt(idStr));
                catalogoService.guardarTipoDecoracion(td);
                break;
            }
            case "color": {
                Color c = new Color();
                c.setNombre(nombre);
                c.setCodigoHex(codigoHex);
                c.setImagen(imagen);
                c.setIdColor(esNuevo ? 0 : Integer.parseInt(idStr));
                catalogoService.guardarColor(c);
                break;
            }
            default:
                break;
        }
    }

    private void cargarDatos(Model model, String tipo) {
        model.addAttribute("tipoActivo", tipo);
        model.addAttribute("seccionActiva", "catalogos");
        switch (tipo) {
            case "decoracion":
                model.addAttribute("decoraciones", catalogoService.listarTodasDecoraciones());
                break;
            case "color":
                model.addAttribute("colores", catalogoService.listarTodosColores());
                break;
            case "evento":
            default:
                model.addAttribute("eventos", catalogoService.listarTodosEventos());
                break;
        }
    }
}
