package com.latinburger.controller.vista;

import com.latinburger.config.SesionKeys;
import com.latinburger.entity.Reserva;
import com.latinburger.entity.Usuario;
import com.latinburger.service.FacturaService;
import com.latinburger.service.PanelClienteService;
import com.latinburger.service.ReservaService;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

/** Panel del cliente, "Mis pedidos" y factura (antes PanelClienteServlet, MisPedidosServlet y FacturaServlet). */
@Controller
public class ClienteController {

    private final PanelClienteService panelClienteService;
    private final ReservaService reservaService;
    private final FacturaService facturaService;

    public ClienteController(PanelClienteService panelClienteService, ReservaService reservaService,
                             FacturaService facturaService) {
        this.panelClienteService = panelClienteService;
        this.reservaService = reservaService;
        this.facturaService = facturaService;
    }

    @GetMapping("/PanelClienteServlet")
    public String panel(HttpSession session, Model model) {
        Usuario usuario = (Usuario) session.getAttribute(SesionKeys.USUARIO_LOGUEADO);
        model.addAttribute("tarjetas", panelClienteService.tarjetas(usuario.getIdUsuario()));
        return "cliente/PanelCliente";
    }

    @GetMapping("/MisPedidosServlet")
    public String misPedidos(HttpSession session, Model model) {
        Usuario usuario = (Usuario) session.getAttribute(SesionKeys.USUARIO_LOGUEADO);
        model.addAttribute("listaPedidos", reservaService.listarPorUsuario(usuario.getIdUsuario()));
        return "cliente/MisPedidos";
    }

    @GetMapping("/FacturaServlet")
    public String factura(@RequestParam(value = "id", required = false) String idParam,
                          HttpSession session, Model model) {
        Usuario usuarioSesion = (Usuario) session.getAttribute(SesionKeys.USUARIO_LOGUEADO);

        Integer idReserva = null;
        if (idParam != null) {
            try {
                idReserva = Integer.parseInt(idParam);
            } catch (NumberFormatException ignored) {
                // se intenta con la última reserva de la sesión
            }
        }
        if (idReserva == null) {
            idReserva = (Integer) session.getAttribute(SesionKeys.ULTIMA_RESERVA_ID);
        }
        if (idReserva == null) {
            return "redirect:/PanelClienteServlet";
        }

        Reserva reserva = facturaService.consultarReserva(idReserva);
        if (reserva == null) {
            model.addAttribute("errorFactura", "No se encontró la reserva solicitada.");
            return "cliente/Factura";
        }
        // Un cliente solo puede ver sus propias facturas; el administrador puede ver cualquiera
        if (!facturaService.puedeVer(usuarioSesion, reserva)) {
            return "redirect:/PanelClienteServlet";
        }
        model.addAllAttributes(facturaService.datosFactura(reserva));
        return "cliente/Factura";
    }
}
