package com.latinburger.controller.api;

import com.latinburger.entity.TipoMenu;
import com.latinburger.service.TipoMenuService;
import java.util.List;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/** Endpoints JSON de tipos de menú (TipoMenuDAO). Solo administradores. */
@RestController
@RequestMapping("/api/admin/tipos-menu")
public class TipoMenuApiController {

    private final TipoMenuService tipoMenuService;

    public TipoMenuApiController(TipoMenuService tipoMenuService) {
        this.tipoMenuService = tipoMenuService;
    }

    @GetMapping
    public List<TipoMenu> listar() {
        return tipoMenuService.listar();
    }

    /** TipoMenuDAO.buscarPersonalizado */
    @GetMapping("/personalizado")
    public ResponseEntity<TipoMenu> personalizado() {
        TipoMenu menu = tipoMenuService.buscarPersonalizado();
        return menu != null ? ResponseEntity.ok(menu) : ResponseEntity.notFound().build();
    }

    @GetMapping("/{id}")
    public ResponseEntity<TipoMenu> consultar(@PathVariable int id) {
        TipoMenu menu = tipoMenuService.consultarTipoMenu(id);
        return menu != null ? ResponseEntity.ok(menu) : ResponseEntity.notFound().build();
    }

    @PostMapping
    public ResponseEntity<Boolean> insertar(@RequestBody TipoMenu menu) {
        return ResponseEntity.ok(tipoMenuService.insertarTipoMenu(menu));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Boolean> actualizar(@PathVariable int id, @RequestBody TipoMenu menu) {
        menu.setIdTipoMenu(id);
        return RolApiController.resultado(tipoMenuService.actualizarTipoMenu(menu));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Boolean> eliminar(@PathVariable int id) {
        return RolApiController.resultado(tipoMenuService.eliminarTipoMenu(id));
    }
}
