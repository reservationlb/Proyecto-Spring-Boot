package com.latinburger.dto;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * Ítem del pedido que el cliente arma en el paso "Menú" del asistente y que se
 * guarda en la sesión ("carritoProductos") hasta confirmar la reserva.
 * Equivale al Map {idProducto, nombre, precioUnitario, cantidad} de la versión con Servlets.
 */
public class ItemCarrito implements Serializable {

    private static final long serialVersionUID = 1L;

    private final int idProducto;
    private final String nombre;
    private final BigDecimal precioUnitario;
    private final int cantidad;

    public ItemCarrito(int idProducto, String nombre, BigDecimal precioUnitario, int cantidad) {
        this.idProducto = idProducto;
        this.nombre = nombre;
        this.precioUnitario = precioUnitario;
        this.cantidad = cantidad;
    }

    public int getIdProducto() { return idProducto; }

    public String getNombre() { return nombre; }

    public BigDecimal getPrecioUnitario() { return precioUnitario; }

    public int getCantidad() { return cantidad; }

    public BigDecimal getSubtotal() {
        return precioUnitario.multiply(BigDecimal.valueOf(cantidad));
    }
}
