package com.latinburger.util;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.sql.Timestamp;
import org.springframework.stereotype.Component;

/**
 * Utilidades de presentación usadas desde Thymeleaf como {@code ${@formato.metodo(...)}}.
 * Reproducen exactamente los formatos de las JSP originales
 * (String.format("%,.0f", ...) y los métodos claseBadge / claseEstado declarados en las JSP).
 */
@Component("formato")
public class Formato {

    /** Equivalente a String.format("%,.0f", valor). */
    public String moneda(Object valor) {
        if (valor == null) {
            return "0";
        }
        if (valor instanceof BigDecimal) {
            return String.format("%,.0f", (BigDecimal) valor);
        }
        if (valor instanceof Number) {
            return String.format("%,.0f", ((Number) valor).doubleValue());
        }
        return String.valueOf(valor);
    }

    /** Equivalente a String.format("%.0f", valor) (sin separador de miles). */
    public String sinSeparador(double valor) {
        return String.format("%.0f", valor);
    }

    /** Equivalente al cast (long) valor que hacía MenuForm.jsp. */
    public long entero(double valor) {
        return (long) valor;
    }

    /** Fecha-hora con el mismo texto que imprimía java.sql.Timestamp en las JSP (p. ej. "2026-01-05 14:03:22.0"). */
    public String fechaHora(LocalDateTime valor) {
        return valor != null ? Timestamp.valueOf(valor).toString() : "";
    }

    /** claseBadge(...) de Dashboard.jsp y Reservas.jsp (panel de administrador). */
    public String claseBadge(String estado) {
        if (estado == null) {
            return "badge-pendiente";
        }
        switch (estado) {
            case "Confirmada":
                return "badge-confirmada";
            case "En preparación":
                return "badge-preparacion";
            case "Entregada":
                return "badge-entregada";
            case "Cancelada":
                return "badge-cancelada";
            default:
                return "badge-pendiente";
        }
    }

    /** claseEstado(...) de PanelCliente.jsp. */
    public String claseEstadoCliente(String estado) {
        if (estado == null) {
            return "badge-Pendiente";
        }
        return "badge-" + estado.trim().replace(" ", "_").replace("ó", "o").replace("í", "i");
    }
}
