package com.latinburger.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/** Catálogo de colores del evento: tabla color_evento (migracion_v2.sql). */
@Entity
@Table(name = "color_evento")
public class Color {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_color")
    private int idColor;

    @Column(name = "nombre", nullable = false, length = 45)
    private String nombre;

    @Column(name = "codigo_hex", nullable = false, length = 7)
    private String codigoHex;

    @Column(name = "imagen")
    private String imagen;

    @Column(name = "activo", nullable = false)
    private boolean activo = true;

    public Color() {
    }

    public int getIdColor() { return idColor; }
    public void setIdColor(int idColor) { this.idColor = idColor; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getCodigoHex() { return codigoHex; }
    public void setCodigoHex(String codigoHex) { this.codigoHex = codigoHex; }

    public String getImagen() { return imagen; }
    public void setImagen(String imagen) { this.imagen = imagen; }

    public boolean isActivo() { return activo; }
    public void setActivo(boolean activo) { this.activo = activo; }
}
