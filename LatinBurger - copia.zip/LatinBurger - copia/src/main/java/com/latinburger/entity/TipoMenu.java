package com.latinburger.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.math.BigDecimal;

@Entity
@Table(name = "tipo_menu")
public class TipoMenu {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_tipo_menu")
    private int idTipoMenu;

    @Column(name = "nombre_menu")
    private String nombreMenu;

    @Column(name = "descripcion_menu")
    private String descripcionMenu;

    @Column(name = "valor_menu")
    private BigDecimal valorMenu;

    public TipoMenu() {
    }

    public TipoMenu(int idTipoMenu, String nombreMenu, String descripcionMenu, BigDecimal valorMenu) {
        this.idTipoMenu = idTipoMenu;
        this.nombreMenu = nombreMenu;
        this.descripcionMenu = descripcionMenu;
        this.valorMenu = valorMenu;
    }

    public int getIdTipoMenu() { return idTipoMenu; }
    public void setIdTipoMenu(int idTipoMenu) { this.idTipoMenu = idTipoMenu; }

    public String getNombreMenu() { return nombreMenu; }
    public void setNombreMenu(String nombreMenu) { this.nombreMenu = nombreMenu; }

    public String getDescripcionMenu() { return descripcionMenu; }
    public void setDescripcionMenu(String descripcionMenu) { this.descripcionMenu = descripcionMenu; }

    public BigDecimal getValorMenu() { return valorMenu; }
    public void setValorMenu(BigDecimal valorMenu) { this.valorMenu = valorMenu; }
}
