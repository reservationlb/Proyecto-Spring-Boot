package com.latinburger.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.math.BigDecimal;

/** Tabla tipo_decoracion (columnas imagen y activo agregadas en migracion_v2.sql). */
@Entity
@Table(name = "tipo_decoracion")
public class TipoDecoracion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_tipo_decoracion")
    private int idTipoDecoracion;

    @Column(name = "nombre_decoracion")
    private String nombreDecoracion;

    @Column(name = "descripcion")
    private String descripcion;

    @Column(name = "valor_decoracion")
    private BigDecimal valorDecoracion;

    @Column(name = "imagen")
    private String imagen;

    @Column(name = "activo", nullable = false)
    private boolean activo = true;

    public TipoDecoracion() {
    }

    public TipoDecoracion(int idTipoDecoracion, String nombreDecoracion, String descripcion, BigDecimal valorDecoracion) {
        this.idTipoDecoracion = idTipoDecoracion;
        this.nombreDecoracion = nombreDecoracion;
        this.descripcion = descripcion;
        this.valorDecoracion = valorDecoracion;
    }

    public int getIdTipoDecoracion() { return idTipoDecoracion; }
    public void setIdTipoDecoracion(int idTipoDecoracion) { this.idTipoDecoracion = idTipoDecoracion; }

    public String getNombreDecoracion() { return nombreDecoracion; }
    public void setNombreDecoracion(String nombreDecoracion) { this.nombreDecoracion = nombreDecoracion; }

    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    public BigDecimal getValorDecoracion() { return valorDecoracion; }
    public void setValorDecoracion(BigDecimal valorDecoracion) { this.valorDecoracion = valorDecoracion; }

    public String getImagen() { return imagen; }
    public void setImagen(String imagen) { this.imagen = imagen; }

    public boolean isActivo() { return activo; }
    public void setActivo(boolean activo) { this.activo = activo; }
}
