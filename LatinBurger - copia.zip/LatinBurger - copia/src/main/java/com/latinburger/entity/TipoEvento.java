package com.latinburger.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.math.BigDecimal;

/** Tabla tipo_evento (columnas imagen y activo agregadas en migracion_v2.sql). */
@Entity
@Table(name = "tipo_evento")
public class TipoEvento {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_tipo_evento")
    private int idTipoEvento;

    @Column(name = "nombre_evento")
    private String nombreEvento;

    @Column(name = "descripcion")
    private String descripcion;

    @Column(name = "valor_evento")
    private BigDecimal valorEvento;

    @Column(name = "imagen")
    private String imagen;

    @Column(name = "activo", nullable = false)
    private boolean activo = true;

    public TipoEvento() {
    }

    public TipoEvento(int idTipoEvento, String nombreEvento, String descripcion, BigDecimal valorEvento) {
        this.idTipoEvento = idTipoEvento;
        this.nombreEvento = nombreEvento;
        this.descripcion = descripcion;
        this.valorEvento = valorEvento;
    }

    public int getIdTipoEvento() { return idTipoEvento; }
    public void setIdTipoEvento(int idTipoEvento) { this.idTipoEvento = idTipoEvento; }

    public String getNombreEvento() { return nombreEvento; }
    public void setNombreEvento(String nombreEvento) { this.nombreEvento = nombreEvento; }

    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    public BigDecimal getValorEvento() { return valorEvento; }
    public void setValorEvento(BigDecimal valorEvento) { this.valorEvento = valorEvento; }

    public String getImagen() { return imagen; }
    public void setImagen(String imagen) { this.imagen = imagen; }

    public boolean isActivo() { return activo; }
    public void setActivo(boolean activo) { this.activo = activo; }
}
