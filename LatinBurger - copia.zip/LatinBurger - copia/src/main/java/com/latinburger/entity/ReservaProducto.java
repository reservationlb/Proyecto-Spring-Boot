package com.latinburger.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import java.math.BigDecimal;

/** Detalle del pedido: tabla reserva_producto (migracion_v1.sql). */
@Entity
@Table(name = "reserva_producto")
public class ReservaProducto {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_reserva_producto")
    private int idReservaProducto;

    @Column(name = "reserva_id_reserva", nullable = false)
    private int reservaIdReserva;

    @Column(name = "producto_id_producto", nullable = false)
    private int productoIdProducto;

    @Column(name = "cantidad", nullable = false)
    private int cantidad;

    @Column(name = "precio_unitario", nullable = false, precision = 10, scale = 2)
    private BigDecimal precioUnitario;

    /** Solo para mostrar en pantalla (no se persiste en esta tabla). */
    @Transient
    private String nombreProducto;

    public ReservaProducto() {
    }

    public int getIdReservaProducto() { return idReservaProducto; }
    public void setIdReservaProducto(int idReservaProducto) { this.idReservaProducto = idReservaProducto; }

    public int getReservaIdReserva() { return reservaIdReserva; }
    public void setReservaIdReserva(int reservaIdReserva) { this.reservaIdReserva = reservaIdReserva; }

    public int getProductoIdProducto() { return productoIdProducto; }
    public void setProductoIdProducto(int productoIdProducto) { this.productoIdProducto = productoIdProducto; }

    public int getCantidad() { return cantidad; }
    public void setCantidad(int cantidad) { this.cantidad = cantidad; }

    public BigDecimal getPrecioUnitario() { return precioUnitario; }
    public void setPrecioUnitario(BigDecimal precioUnitario) { this.precioUnitario = precioUnitario; }

    public String getNombreProducto() { return nombreProducto; }
    public void setNombreProducto(String nombreProducto) { this.nombreProducto = nombreProducto; }

    @Transient
    public BigDecimal getSubtotal() {
        if (precioUnitario == null) {
            return BigDecimal.ZERO;
        }
        return precioUnitario.multiply(BigDecimal.valueOf(cantidad));
    }
}
