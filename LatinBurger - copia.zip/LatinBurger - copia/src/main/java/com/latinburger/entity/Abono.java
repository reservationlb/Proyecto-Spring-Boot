package com.latinburger.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/** Tabla abono (migracion_v1.sql). */
@Entity
@Table(name = "abono")
public class Abono {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_abono")
    private int idAbono;

    @Column(name = "reserva_id_reserva", nullable = false)
    private int reservaIdReserva;

    @Column(name = "medio_pago", nullable = false, length = 45)
    private String medioPago;

    @Column(name = "valor_abono", nullable = false, precision = 10, scale = 2)
    private BigDecimal valorAbono;

    /** DEFAULT CURRENT_TIMESTAMP en MySQL: lo asigna la base de datos, igual que el DAO original. */
    @Column(name = "fecha_abono", insertable = false, updatable = false)
    private LocalDateTime fechaAbono;

    @Column(name = "estado", nullable = false, length = 45)
    private String estado;

    public Abono() {
    }

    public int getIdAbono() { return idAbono; }
    public void setIdAbono(int idAbono) { this.idAbono = idAbono; }

    public int getReservaIdReserva() { return reservaIdReserva; }
    public void setReservaIdReserva(int reservaIdReserva) { this.reservaIdReserva = reservaIdReserva; }

    public String getMedioPago() { return medioPago; }
    public void setMedioPago(String medioPago) { this.medioPago = medioPago; }

    public BigDecimal getValorAbono() { return valorAbono; }
    public void setValorAbono(BigDecimal valorAbono) { this.valorAbono = valorAbono; }

    public LocalDateTime getFechaAbono() { return fechaAbono; }
    public void setFechaAbono(LocalDateTime fechaAbono) { this.fechaAbono = fechaAbono; }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
}
