package com.latinburger.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

/**
 * Tabla reserva. Las claves foráneas se mapean como columnas simples, tal como
 * las manejaba el modelo original, para no alterar el esquema ni inventar relaciones.
 */
@Entity
@Table(name = "reserva")
public class Reserva {

    private static final DateTimeFormatter HORA = DateTimeFormatter.ofPattern("HH:mm:ss");

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_reserva")
    private int idReserva;

    @Column(name = "hora")
    private LocalTime hora;

    @Column(name = "fecha")
    private LocalDate fecha;

    @Column(name = "numero_persona")
    private int numeroPersona;

    @Column(name = "valor_reserva")
    private BigDecimal valorReserva;

    @Column(name = "disponibilidad_id_disponibilidad")
    private int disponibilidadIdDisponibilidad;

    @Column(name = "tipo_menu_id_tipo_menu")
    private int tipoMenuIdTipoMenu;

    @Column(name = "tipo_decoracion_id_tipo_decoracion")
    private int tipoDecoracionIdTipoDecoracion;

    @Column(name = "tipo_evento_id_tipo_evento")
    private int tipoEventoIdTipoEvento;

    @Column(name = "usuario_id_usuario")
    private int usuarioIdUsuario;

    @Column(name = "estado", nullable = false, length = 45)
    private String estado = "Pendiente";

    @Column(name = "color_evento", length = 45)
    private String colorEvento;

    @Column(name = "comentarios")
    private String comentarios;

    public Reserva() {
    }

    public Reserva(int idReserva, LocalTime hora, LocalDate fecha, int numeroPersona, BigDecimal valorReserva,
                   int disponibilidadIdDisponibilidad, int tipoMenuIdTipoMenu,
                   int tipoDecoracionIdTipoDecoracion, int tipoEventoIdTipoEvento, int usuarioIdUsuario) {
        this.idReserva = idReserva;
        this.hora = hora;
        this.fecha = fecha;
        this.numeroPersona = numeroPersona;
        this.valorReserva = valorReserva;
        this.disponibilidadIdDisponibilidad = disponibilidadIdDisponibilidad;
        this.tipoMenuIdTipoMenu = tipoMenuIdTipoMenu;
        this.tipoDecoracionIdTipoDecoracion = tipoDecoracionIdTipoDecoracion;
        this.tipoEventoIdTipoEvento = tipoEventoIdTipoEvento;
        this.usuarioIdUsuario = usuarioIdUsuario;
    }

    public int getIdReserva() { return idReserva; }
    public void setIdReserva(int idReserva) { this.idReserva = idReserva; }

    public LocalTime getHora() { return hora; }
    public void setHora(LocalTime hora) { this.hora = hora; }

    public LocalDate getFecha() { return fecha; }
    public void setFecha(LocalDate fecha) { this.fecha = fecha; }

    public int getNumeroPersona() { return numeroPersona; }
    public void setNumeroPersona(int numeroPersona) { this.numeroPersona = numeroPersona; }

    public BigDecimal getValorReserva() { return valorReserva; }
    public void setValorReserva(BigDecimal valorReserva) { this.valorReserva = valorReserva; }

    public int getDisponibilidadIdDisponibilidad() { return disponibilidadIdDisponibilidad; }
    public void setDisponibilidadIdDisponibilidad(int disponibilidadIdDisponibilidad) { this.disponibilidadIdDisponibilidad = disponibilidadIdDisponibilidad; }

    public int getTipoMenuIdTipoMenu() { return tipoMenuIdTipoMenu; }
    public void setTipoMenuIdTipoMenu(int tipoMenuIdTipoMenu) { this.tipoMenuIdTipoMenu = tipoMenuIdTipoMenu; }

    public int getTipoDecoracionIdTipoDecoracion() { return tipoDecoracionIdTipoDecoracion; }
    public void setTipoDecoracionIdTipoDecoracion(int tipoDecoracionIdTipoDecoracion) { this.tipoDecoracionIdTipoDecoracion = tipoDecoracionIdTipoDecoracion; }

    public int getTipoEventoIdTipoEvento() { return tipoEventoIdTipoEvento; }
    public void setTipoEventoIdTipoEvento(int tipoEventoIdTipoEvento) { this.tipoEventoIdTipoEvento = tipoEventoIdTipoEvento; }

    public int getUsuarioIdUsuario() { return usuarioIdUsuario; }
    public void setUsuarioIdUsuario(int usuarioIdUsuario) { this.usuarioIdUsuario = usuarioIdUsuario; }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }

    public String getColorEvento() { return colorEvento; }
    public void setColorEvento(String colorEvento) { this.colorEvento = colorEvento; }

    public String getComentarios() { return comentarios; }
    public void setComentarios(String comentarios) { this.comentarios = comentarios; }

    @Transient
    public String getFechaTexto() { return fecha != null ? fecha.toString() : ""; }

    @Transient
    public String getHoraTexto() { return hora != null ? hora.format(HORA) : ""; }
}
