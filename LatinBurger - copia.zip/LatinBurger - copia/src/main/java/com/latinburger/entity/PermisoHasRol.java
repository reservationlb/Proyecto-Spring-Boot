package com.latinburger.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Table;

/** Tabla intermedia permiso_has_rol (relación N:M entre permiso y rol). */
@Entity
@Table(name = "permiso_has_rol")
@IdClass(PermisoHasRolId.class)
public class PermisoHasRol {

    @Id
    @Column(name = "permiso_id_permiso")
    private int permisoIdPermiso;

    @Id
    @Column(name = "rol_id_rol")
    private int rolIdRol;

    public PermisoHasRol() {
    }

    public PermisoHasRol(int permisoIdPermiso, int rolIdRol) {
        this.permisoIdPermiso = permisoIdPermiso;
        this.rolIdRol = rolIdRol;
    }

    public int getPermisoIdPermiso() { return permisoIdPermiso; }
    public void setPermisoIdPermiso(int permisoIdPermiso) { this.permisoIdPermiso = permisoIdPermiso; }

    public int getRolIdRol() { return rolIdRol; }
    public void setRolIdRol(int rolIdRol) { this.rolIdRol = rolIdRol; }
}
