package com.latinburger.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

/** Tabla disponibilidad: ciclo Disponible -> Ocupado -> Disponible. */
@Entity
@Table(name = "disponibilidad")
public class Disponibilidad {

    private static final DateTimeFormatter HORA = DateTimeFormatter.ofPattern("HH:mm:ss");

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_disponibilidad")
    private int idDisponibilidad;

    @Column(name = "fecha")
    private LocalDate fecha;

    @Column(name = "hora")
    private LocalTime hora;

    @Column(name = "estado")
    private String estado;

    public Disponibilidad() {
    }

    public Disponibilidad(int idDisponibilidad, LocalDate fecha, LocalTime hora, String estado) {
        this.idDisponibilidad = idDisponibilidad;
        this.fecha = fecha;
        this.hora = hora;
        this.estado = estado;
    }

    public int getIdDisponibilidad() { return idDisponibilidad; }
    public void setIdDisponibilidad(int idDisponibilidad) { this.idDisponibilidad = idDisponibilidad; }

    public LocalDate getFecha() { return fecha; }
    public void setFecha(LocalDate fecha) { this.fecha = fecha; }

    public LocalTime getHora() { return hora; }
    public void setHora(LocalTime hora) { this.hora = hora; }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }

    /** Fecha como texto yyyy-MM-dd (mismo formato que java.sql.Date.toString() en la versión JSP). */
    @Transient
    public String getFechaTexto() { return fecha != null ? fecha.toString() : ""; }

    /** Hora como texto HH:mm:ss (mismo formato que java.sql.Time.toString() en la versión JSP). */
    @Transient
    public String getHoraTexto() { return hora != null ? hora.format(HORA) : ""; }
}
