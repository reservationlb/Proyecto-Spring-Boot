package com.latinburger.entity;

import java.io.Serializable;
import java.util.Objects;

/** Clave primaria compuesta de permiso_has_rol (permiso_id_permiso, rol_id_rol). */
public class PermisoHasRolId implements Serializable {

    private static final long serialVersionUID = 1L;

    private int permisoIdPermiso;
    private int rolIdRol;

    public PermisoHasRolId() {
    }

    public PermisoHasRolId(int permisoIdPermiso, int rolIdRol) {
        this.permisoIdPermiso = permisoIdPermiso;
        this.rolIdRol = rolIdRol;
    }

    public int getPermisoIdPermiso() { return permisoIdPermiso; }
    public void setPermisoIdPermiso(int permisoIdPermiso) { this.permisoIdPermiso = permisoIdPermiso; }

    public int getRolIdRol() { return rolIdRol; }
    public void setRolIdRol(int rolIdRol) { this.rolIdRol = rolIdRol; }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof PermisoHasRolId)) {
            return false;
        }
        PermisoHasRolId that = (PermisoHasRolId) o;
        return permisoIdPermiso == that.permisoIdPermiso && rolIdRol == that.rolIdRol;
    }

    @Override
    public int hashCode() {
        return Objects.hash(permisoIdPermiso, rolIdRol);
    }
}
