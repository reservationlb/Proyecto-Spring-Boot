package com.latinburger.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import java.io.Serializable;
import java.time.LocalDate;

/**
 * Tabla usuario. Solo se mapean las columnas que existen en la base de datos
 * (las mismas que leía y escribía UsuarioDAO). Los campos correo y rolDescripcion
 * del modelo original no son columnas: quedan como @Transient.
 * Serializable porque el usuario autenticado se guarda en la sesión HTTP.
 */
@Entity
@Table(name = "usuario")
public class Usuario implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_usuario")
    private int idUsuario;

    @Column(name = "nombre")
    private String nombre;

    @Column(name = "apellido")
    private String apellido;

    @Column(name = "direccion")
    private String direccion;

    /** Columna "documento" de la BD (en el modelo original: numeroDocumento / documento). */
    @Column(name = "documento")
    private String numeroDocumento;

    @Column(name = "telefono")
    private String telefono;

    @Column(name = "fecha_nacimiento")
    private LocalDate fechaNacimiento;

    @Column(name = "fecha_de_vencimiento_clave")
    private LocalDate fechaDeVencimientoClave;

    @Column(name = "autorizacion_dato")
    private LocalDate autorizacionDato;

    /** Columna "password" de la BD (en el modelo original: contrasena / password). */
    @Column(name = "password")
    private String contrasena;

    @Column(name = "estado")
    private String estado;

    @Column(name = "rol_id_rol")
    private int rolIdRol;

    @Column(name = "tipo_documento_idtipo_documento")
    private int tipoDocumentoIdTipoDocumento;

    @Transient
    private String correo;

    /** Columna "user_name" (NOT NULL en la BD): si no se indica, se genera al registrar. */
    @Column(name = "user_name", nullable = false, length = 45)
    private String userName;

    /** Solo para mostrar en listados (JOIN con rol), no se persiste. */
    @Transient
    private String rolDescripcion;

    public Usuario() {
    }

    public int getIdUsuario() { return idUsuario; }
    public void setIdUsuario(int idUsuario) { this.idUsuario = idUsuario; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getApellido() { return apellido; }
    public void setApellido(String apellido) { this.apellido = apellido; }

    public String getDireccion() { return direccion; }
    public void setDireccion(String direccion) { this.direccion = direccion; }

    public String getNumeroDocumento() { return numeroDocumento; }
    public void setNumeroDocumento(String numeroDocumento) { this.numeroDocumento = numeroDocumento; }

    /** Alias de compatibilidad del modelo original. */
    @Transient
    public String getDocumento() { return numeroDocumento; }
    public void setDocumento(String documento) { this.numeroDocumento = documento; }

    public String getTelefono() { return telefono; }
    public void setTelefono(String telefono) { this.telefono = telefono; }

    public String getCorreo() { return correo; }
    public void setCorreo(String correo) { this.correo = correo; }

    public LocalDate getFechaNacimiento() { return fechaNacimiento; }
    public void setFechaNacimiento(LocalDate fechaNacimiento) { this.fechaNacimiento = fechaNacimiento; }

    public LocalDate getFechaDeVencimientoClave() { return fechaDeVencimientoClave; }
    public void setFechaDeVencimientoClave(LocalDate fechaDeVencimientoClave) { this.fechaDeVencimientoClave = fechaDeVencimientoClave; }

    public LocalDate getAutorizacionDato() { return autorizacionDato; }
    public void setAutorizacionDato(LocalDate autorizacionDato) { this.autorizacionDato = autorizacionDato; }

    public String getUserName() { return userName; }
    public void setUserName(String userName) { this.userName = userName; }

    public String getContrasena() { return contrasena; }
    public void setContrasena(String contrasena) { this.contrasena = contrasena; }

    /** Alias de compatibilidad del modelo original. */
    @Transient
    public String getPassword() { return contrasena; }
    public void setPassword(String password) { this.contrasena = password; }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }

    public int getRolIdRol() { return rolIdRol; }
    public void setRolIdRol(int rolIdRol) { this.rolIdRol = rolIdRol; }

    public int getTipoDocumentoIdTipoDocumento() { return tipoDocumentoIdTipoDocumento; }
    public void setTipoDocumentoIdTipoDocumento(int tipoDocumentoIdTipoDocumento) { this.tipoDocumentoIdTipoDocumento = tipoDocumentoIdTipoDocumento; }

    public String getRolDescripcion() { return rolDescripcion; }
    public void setRolDescripcion(String rolDescripcion) { this.rolDescripcion = rolDescripcion; }
}
