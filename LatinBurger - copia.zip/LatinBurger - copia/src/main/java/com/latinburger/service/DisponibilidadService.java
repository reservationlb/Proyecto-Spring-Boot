package com.latinburger.service;

import com.latinburger.entity.Disponibilidad;
import com.latinburger.repository.DisponibilidadRepository;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/** Horarios disponibles para eventos (antes DisponibilidadDAO). */
@Service
@Transactional(readOnly = true)
public class DisponibilidadService {

    private static final Logger log = LoggerFactory.getLogger(DisponibilidadService.class);

    public static final String DISPONIBLE = "Disponible";

    private final DisponibilidadRepository disponibilidadRepository;

    public DisponibilidadService(DisponibilidadRepository disponibilidadRepository) {
        this.disponibilidadRepository = disponibilidadRepository;
    }

    /** DisponibilidadDAO.listarDisponibles(fechaFiltro): solo 'Disponible' y desde hoy. */
    public List<Disponibilidad> listarDisponibles(LocalDate fechaFiltro) {
        return fechaFiltro != null
                ? disponibilidadRepository.listarDisponiblesPorFecha(fechaFiltro)
                : disponibilidadRepository.listarDisponibles();
    }

    /** DisponibilidadDAO.listarTodas (panel de administrador). */
    public List<Disponibilidad> listarTodas() {
        return disponibilidadRepository.findAllByOrderByFechaDescHoraAsc();
    }

    /** DisponibilidadDAO.consultarPorFechaYHora: solo si sigue 'Disponible'. */
    public Disponibilidad consultarPorFechaYHora(LocalDate fecha, LocalTime hora) {
        Disponibilidad disp = disponibilidadRepository.findFirstByFechaAndHoraAndEstado(fecha, hora, DISPONIBLE)
                .orElse(null);
        if (disp == null && log.isDebugEnabled()) {
            log.debug("[DisponibilidadService] fecha='{}' hora='{}' estado='Disponible' -> SIN COINCIDENCIA.", fecha, hora);
            List<Disponibilidad> mismasFechas = disponibilidadRepository.findByFecha(fecha);
            if (mismasFechas.isEmpty()) {
                log.debug("[DisponibilidadService] No existe ninguna disponibilidad con fecha = '{}'.", fecha);
            }
            for (Disponibilidad d : mismasFechas) {
                log.debug("  -> id={} fecha='{}' hora='{}' estado='{}'", d.getIdDisponibilidad(),
                        d.getFecha(), d.getHora(), d.getEstado());
            }
        }
        return disp;
    }

    public Disponibilidad consultarDisponibilidad(int id) {
        return disponibilidadRepository.findById(id).orElse(null);
    }

    /**
     * DisponibilidadDAO.ocuparDisponibilidad: debe ejecutarse dentro de la transacción
     * de la reserva. Devuelve false si otro cliente ya tomó el horario.
     */
    @Transactional
    public boolean ocuparDisponibilidad(int id) {
        return disponibilidadRepository.ocupar(id) > 0;
    }

    @Transactional
    public boolean liberarDisponibilidad(int id) {
        return disponibilidadRepository.liberar(id) > 0;
    }

    @Transactional
    public boolean insertarDisponibilidad(Disponibilidad disp) {
        disp.setIdDisponibilidad(0);
        disponibilidadRepository.save(disp);
        return true;
    }

    @Transactional
    public boolean actualizarDisponibilidad(Disponibilidad disp) {
        if (!disponibilidadRepository.existsById(disp.getIdDisponibilidad())) {
            return false;
        }
        disponibilidadRepository.save(disp);
        return true;
    }

    @Transactional
    public boolean inactivarDisponibilidad(int id) {
        return disponibilidadRepository.inactivar(id) > 0;
    }

    @Transactional
    public boolean activarDisponibilidad(int id) {
        return disponibilidadRepository.activar(id) > 0;
    }

    @Transactional
    public boolean eliminarDisponibilidad(int id) {
        if (!disponibilidadRepository.existsById(id)) {
            return false;
        }
        disponibilidadRepository.deleteById(id);
        return true;
    }

    /**
     * AdminDisponibilidadServlet "eliminar": solo se elimina un horario que siga 'Disponible'
     * (uno ocupado pertenece a una reserva existente).
     */
    @Transactional
    public boolean eliminarSiDisponible(int id) {
        Disponibilidad d = disponibilidadRepository.findById(id).orElse(null);
        if (d != null && DISPONIBLE.equals(d.getEstado())) {
            disponibilidadRepository.delete(d);
            return true;
        }
        return false;
    }

    /** Disponibilidad.jsp espera List&lt;Map&gt; con claves fecha / hora / estado. */
    public List<Map<String, String>> convertirAMapa(List<Disponibilidad> lista) {
        List<Map<String, String>> resultado = new ArrayList<>();
        for (Disponibilidad d : lista) {
            Map<String, String> item = new HashMap<>();
            item.put("fecha", d.getFechaTexto());
            item.put("hora", d.getHoraTexto());
            item.put("estado", d.getEstado());
            resultado.add(item);
        }
        return resultado;
    }
}
