package com.latinburger.service;

import com.latinburger.entity.ReservaProducto;
import com.latinburger.repository.ReservaProductoRepository;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/** Detalle de platos de cada reserva (antes ReservaProductoDAO). */
@Service
@Transactional(readOnly = true)
public class ReservaProductoService {

    private final ReservaProductoRepository reservaProductoRepository;

    public ReservaProductoService(ReservaProductoRepository reservaProductoRepository) {
        this.reservaProductoRepository = reservaProductoRepository;
    }

    @Transactional
    public ReservaProducto insertar(ReservaProducto item) {
        return reservaProductoRepository.save(item);
    }

    /** ReservaProductoDAO.listarPorReserva: incluye el nombre del producto (JOIN Producto). */
    public List<ReservaProducto> listarPorReserva(int idReserva) {
        List<ReservaProducto> lista = new ArrayList<>();
        for (Object[] fila : reservaProductoRepository.listarPorReservaConNombre(idReserva)) {
            ReservaProducto item = (ReservaProducto) fila[0];
            item.setNombreProducto((String) fila[1]);
            lista.add(item);
        }
        return lista;
    }

    /** ReservaProductoDAO.popularidadPlatos(limite): nombre, unidades, ingresos ("%,.0f"). */
    public List<Map<String, String>> popularidadPlatos(int limite) {
        List<Map<String, String>> lista = new ArrayList<>();
        for (Object[] fila : reservaProductoRepository.popularidadPlatos(PageRequest.of(0, limite))) {
            Map<String, String> m = new HashMap<>();
            m.put("nombre", (String) fila[0]);
            m.put("unidades", String.valueOf(fila[1] != null ? ((Number) fila[1]).intValue() : 0));
            m.put("ingresos", String.format("%,.0f", fila[2] != null ? ((Number) fila[2]).doubleValue() : 0d));
            lista.add(m);
        }
        return lista;
    }
}
