package com.latinburger.service;

import com.latinburger.entity.Abono;
import com.latinburger.entity.Reserva;
import com.latinburger.entity.ReservaProducto;
import com.latinburger.entity.TipoDecoracion;
import com.latinburger.entity.TipoEvento;
import com.latinburger.repository.ReservaRepository;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Reservas (antes ReservaDAO): confirmación transaccional, consultas para el cliente
 * y el administrador, cambios de estado, cancelación y métricas.
 */
@Service
@Transactional(readOnly = true)
public class ReservaService {

    /** Resultado de {@link #insertarReservaCompleta}: el horario ya no estaba disponible. */
    public static final int HORARIO_NO_DISPONIBLE = -1;

    /** Resultado usado por los controladores cuando ocurre un error inesperado. */
    public static final int ERROR_INESPERADO = -2;

    public static final String PENDIENTE = "Pendiente";
    public static final String CANCELADA = "Cancelada";

    private final ReservaRepository reservaRepository;
    private final DisponibilidadService disponibilidadService;
    private final ReservaProductoService reservaProductoService;
    private final AbonoService abonoService;

    public ReservaService(ReservaRepository reservaRepository,
                          DisponibilidadService disponibilidadService,
                          ReservaProductoService reservaProductoService,
                          AbonoService abonoService) {
        this.reservaRepository = reservaRepository;
        this.disponibilidadService = disponibilidadService;
        this.reservaProductoService = reservaProductoService;
        this.abonoService = abonoService;
    }

    /**
     * ReservaDAO.insertarReservaCompleta, en una sola transacción:
     * 1) ocupa el horario (UPDATE condicionado a estado = 'Disponible'),
     * 2) inserta la reserva con estado 'Pendiente',
     * 3) inserta cada ítem del pedido (reserva_producto),
     * 4) inserta el abono si se indicó uno.
     * Si el horario ya fue tomado por otro cliente devuelve -1 sin escribir nada.
     * Cualquier error de base de datos revierte todo (rollback) y se propaga.
     *
     * @return id_reserva generado, o -1 si el horario ya no estaba disponible.
     */
    @Transactional
    public int insertarReservaCompleta(Reserva reserva, List<ReservaProducto> items, Abono abono) {
        boolean ocupado = disponibilidadService.ocuparDisponibilidad(reserva.getDisponibilidadIdDisponibilidad());
        if (!ocupado) {
            return HORARIO_NO_DISPONIBLE;
        }

        reserva.setIdReserva(0);
        reserva.setEstado(PENDIENTE);
        Reserva guardada = reservaRepository.saveAndFlush(reserva);
        int idReservaGenerado = guardada.getIdReserva();

        if (items != null) {
            for (ReservaProducto item : items) {
                item.setReservaIdReserva(idReservaGenerado);
                reservaProductoService.insertar(item);
            }
        }
        if (abono != null) {
            abono.setReservaIdReserva(idReservaGenerado);
            abonoService.insertar(abono);
        }
        return idReservaGenerado;
    }

    /** Total del evento = valor del tipo de evento + valor de la decoración + platos. */
    public BigDecimal calcularTotal(TipoEvento evento, TipoDecoracion decoracion, BigDecimal totalPlatos) {
        BigDecimal valorEvento = evento != null && evento.getValorEvento() != null ? evento.getValorEvento() : BigDecimal.ZERO;
        BigDecimal valorDecoracion = decoracion != null && decoracion.getValorDecoracion() != null
                ? decoracion.getValorDecoracion() : BigDecimal.ZERO;
        return valorEvento.add(valorDecoracion).add(totalPlatos != null ? totalPlatos : BigDecimal.ZERO);
    }

    /**
     * ReservaDAO.listarPorUsuario (Mis Pedidos): mapas con las claves
     * id_pedido, fecha ("fecha hora"), total, estado, evento, decoracion.
     */
    public List<Map<String, String>> listarPorUsuario(int idUsuario) {
        List<Map<String, String>> lista = new ArrayList<>();
        for (Object[] fila : reservaRepository.listarPorUsuarioConDetalle(idUsuario)) {
            Reserva r = (Reserva) fila[0];
            Map<String, String> m = new HashMap<>();
            m.put("id_pedido", String.valueOf(r.getIdReserva()));
            m.put("fecha", r.getFechaTexto() + " " + r.getHoraTexto());
            m.put("total", formatoMiles(r.getValorReserva()));
            m.put("estado", r.getEstado());
            m.put("evento", (String) fila[1]);
            m.put("decoracion", (String) fila[2]);
            lista.add(m);
        }
        return lista;
    }

    /**
     * ReservaDAO.listarTodasConDetalle (administrador): mapas con las claves
     * id_reserva, fecha, hora, numero_persona, total, estado, evento, decoracion, cliente.
     */
    public List<Map<String, String>> listarTodasConDetalle() {
        List<Map<String, String>> lista = new ArrayList<>();
        for (Object[] fila : reservaRepository.listarTodasConDetalle()) {
            Reserva r = (Reserva) fila[0];
            Map<String, String> m = new HashMap<>();
            m.put("id_reserva", String.valueOf(r.getIdReserva()));
            m.put("fecha", r.getFechaTexto());
            m.put("hora", r.getHoraTexto());
            m.put("numero_persona", String.valueOf(r.getNumeroPersona()));
            m.put("total", formatoMiles(r.getValorReserva()));
            m.put("estado", r.getEstado());
            m.put("evento", (String) fila[1]);
            m.put("decoracion", (String) fila[2]);
            m.put("cliente", fila[3] + " " + fila[4]);
            lista.add(m);
        }
        return lista;
    }

    /** ReservaDAO.listarPorUsuarioCompleta */
    public List<Reserva> listarPorUsuarioCompleta(int idUsuario) {
        return reservaRepository.findByUsuarioIdUsuarioOrderByFechaDescHoraDesc(idUsuario);
    }

    /** ReservaDAO.consultarReserva */
    public Reserva consultarReserva(int idReserva) {
        return reservaRepository.findById(idReserva).orElse(null);
    }

    /** ReservaDAO.actualizarEstado */
    @Transactional
    public boolean actualizarEstado(int idReserva, String nuevoEstado) {
        return reservaRepository.actualizarEstado(idReserva, nuevoEstado) > 0;
    }

    /** ReservaDAO.cancelarReserva: estado 'Cancelada' y libera el horario. */
    @Transactional
    public boolean cancelarReserva(int idReserva) {
        Reserva r = consultarReserva(idReserva);
        if (r == null) {
            return false;
        }
        int idDisponibilidad = r.getDisponibilidadIdDisponibilidad();
        boolean actualizado = actualizarEstado(idReserva, CANCELADA);
        if (actualizado) {
            disponibilidadService.liberarDisponibilidad(idDisponibilidad);
        }
        return actualizado;
    }

    /** ReservaDAO.insertarReserva (inserción simple, sin detalle ni abono). */
    @Transactional
    public boolean insertarReserva(Reserva reserva) {
        reserva.setIdReserva(0);
        reservaRepository.save(reserva);
        return true;
    }

    /** ReservaDAO.actualizarReserva */
    @Transactional
    public boolean actualizarReserva(Reserva reserva) {
        if (!reservaRepository.existsById(reserva.getIdReserva())) {
            return false;
        }
        reservaRepository.save(reserva);
        return true;
    }

    /** ReservaDAO.eliminarReserva (reserva_producto y abono se borran en cascada por la FK). */
    @Transactional
    public boolean eliminarReserva(int idReserva) {
        if (!reservaRepository.existsById(idReserva)) {
            return false;
        }
        reservaRepository.deleteById(idReserva);
        return true;
    }

    // ---------------------------- métricas ----------------------------

    public int contarReservasHoy() {
        return entero(reservaRepository.contarReservasHoy());
    }

    public double sumarValorHoy() {
        return decimal(reservaRepository.sumarValorHoy());
    }

    public int contarReservasPendientes() {
        return entero(reservaRepository.contarReservasPendientes());
    }

    public int contarReservasMes(int anio, int mes) {
        return entero(reservaRepository.contarReservasMes(anio, mes));
    }

    public double sumarValorMes(int anio, int mes) {
        return decimal(reservaRepository.sumarValorMes(anio, mes));
    }

    private static int entero(Number n) {
        return n != null ? n.intValue() : 0;
    }

    private static double decimal(Number n) {
        return n != null ? n.doubleValue() : 0d;
    }

    private static String formatoMiles(BigDecimal valor) {
        return String.format("%,.0f", valor != null ? valor.doubleValue() : 0d);
    }
}
