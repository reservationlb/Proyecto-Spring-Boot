package com.latinburger.service;

import com.latinburger.config.SesionKeys;
import com.latinburger.entity.Usuario;
import com.latinburger.repository.UsuarioRepository;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * Lógica de negocio de usuarios (antes UsuarioDAO + LoginServlet/RegistroServlet/AdminUsuario*Servlet).
 * La validación de contraseña se mantiene igual que en el sistema original (comparación directa
 * contra la columna password) para conservar la compatibilidad con los usuarios existentes.
 */
@Service
@Transactional(readOnly = true)
public class UsuarioService {

    private static final Logger log = LoggerFactory.getLogger(UsuarioService.class);

    private final UsuarioRepository usuarioRepository;

    public UsuarioService(UsuarioRepository usuarioRepository) {
        this.usuarioRepository = usuarioRepository;
    }

    /** UsuarioDAO.validarUsuario: login por número de documento + contraseña. */
    public Usuario validarUsuario(String numeroDocumento, String contrasena) {
        if (numeroDocumento == null || contrasena == null) {
            return null;
        }
        return usuarioRepository.findFirstByNumeroDocumentoAndContrasena(numeroDocumento, contrasena).orElse(null);
    }

    /**
     * UsuarioDAO.insertarUsuario: genera fecha_de_vencimiento_clave (hoy + 1 año) y
     * autorizacion_dato (hoy) para cumplir las restricciones NOT NULL; estado por defecto
     * "Activo" y rol por defecto 2 (Cliente).
     * Igual que el DAO, un error de base de datos (p. ej. documento duplicado) devuelve false.
     * Se ejecuta fuera de una transacción externa para que el repositorio confirme o
     * revierta su propia operación y el error no marque como rollback otra transacción.
     */
    @Transactional(propagation = Propagation.NOT_SUPPORTED)
    public boolean insertarUsuario(Usuario usuario) {
        try {
            if (usuario.getNumeroDocumento() != null
                    && usuarioRepository.findFirstByNumeroDocumento(usuario.getNumeroDocumento()).isPresent()) {
                log.warn("Registro rechazado: el documento {} ya existe", usuario.getNumeroDocumento());
                return false;
            }
            usuario.setIdUsuario(0);
            if (usuario.getUserName() == null || usuario.getUserName().isBlank()) {
                usuario.setUserName(generarUserName(usuario));
            }
            usuario.setFechaDeVencimientoClave(LocalDate.now().plusYears(1));
            usuario.setAutorizacionDato(LocalDate.now());
            if (usuario.getEstado() == null) {
                usuario.setEstado("Activo");
            }
            if (usuario.getRolIdRol() <= 0) {
                usuario.setRolIdRol(SesionKeys.ROL_CLIENTE);
            }
            usuarioRepository.saveAndFlush(usuario);
            return true;
        } catch (DataAccessException e) {
            log.error("Error al insertar usuario en BD: {}", e.getMessage(), e);
            return false;
        }
    }

    /** Indica si ya existe un usuario con ese número de documento. */
    public boolean existeDocumento(String documento) {
        return documento != null && usuarioRepository.findFirstByNumeroDocumento(documento.trim()).isPresent();
    }

    /**
     * Genera el valor de user_name (NOT NULL, máx. 45) con el formato de los datos
     * existentes: "nombre.apellido" en minúsculas y sin tildes; si no hay nombre, el documento.
     */
    static String generarUserName(Usuario usuario) {
        String base = limpiar(usuario.getNombre()) + "." + limpiar(usuario.getApellido());
        if (base.equals(".")) {
            base = usuario.getNumeroDocumento() != null ? usuario.getNumeroDocumento() : "usuario";
        } else if (base.startsWith(".") || base.endsWith(".")) {
            base = base.replace(".", "");
        }
        return base.length() > 45 ? base.substring(0, 45) : base;
    }

    private static String limpiar(String texto) {
        if (texto == null) {
            return "";
        }
        String sinTildes = java.text.Normalizer.normalize(texto.trim().toLowerCase(), java.text.Normalizer.Form.NFD)
                .replaceAll("\\p{M}", "");
        String[] partes = sinTildes.replaceAll("[^a-z0-9 ]", "").trim().split("\\s+");
        return partes.length > 0 ? partes[0] : "";
    }

    /** UsuarioDAO.consultarUsuario (por número de documento). */
    public Usuario consultarUsuario(String documento) {
        return usuarioRepository.findFirstByNumeroDocumento(documento).orElse(null);
    }

    /** UsuarioDAO.consultarPorId */
    public Usuario consultarPorId(int idUsuario) {
        return usuarioRepository.findById(idUsuario).orElse(null);
    }

    /** UsuarioDAO.listar: todos los usuarios con la descripción del rol (INNER JOIN rol). */
    public List<Usuario> listar() {
        List<Usuario> lista = new ArrayList<>();
        for (Object[] fila : usuarioRepository.listarConRol()) {
            Usuario u = (Usuario) fila[0];
            u.setRolDescripcion((String) fila[1]);
            lista.add(u);
        }
        return lista;
    }

    /** UsuarioDAO.actualizarUsuario: actualiza nombre, apellido, dirección y teléfono. */
    @Transactional
    public boolean actualizarUsuario(Usuario usuario) {
        return usuarioRepository.actualizarDatos(usuario.getIdUsuario(), usuario.getNombre(),
                usuario.getApellido(), usuario.getDireccion(), usuario.getTelefono()) > 0;
    }

    /** UsuarioDAO.eliminarUsuario */
    @Transactional
    public boolean eliminarUsuario(int idUsuario) {
        Optional<Usuario> u = usuarioRepository.findById(idUsuario);
        if (u.isEmpty()) {
            return false;
        }
        usuarioRepository.delete(u.get());
        return true;
    }

    /** UsuarioDAO.activarUsuario */
    @Transactional
    public boolean activarUsuario(int idUsuario) {
        return usuarioRepository.cambiarEstado(idUsuario, "Activo") > 0;
    }

    /** UsuarioDAO.inactivarUsuario */
    @Transactional
    public boolean inactivarUsuario(int idUsuario) {
        return usuarioRepository.cambiarEstado(idUsuario, "Inactivo") > 0;
    }
}
