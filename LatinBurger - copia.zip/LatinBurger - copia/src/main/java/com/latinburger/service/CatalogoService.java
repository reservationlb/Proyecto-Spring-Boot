package com.latinburger.service;

import com.latinburger.entity.Categoria;
import com.latinburger.entity.Color;
import com.latinburger.entity.TipoDecoracion;
import com.latinburger.entity.TipoEvento;
import com.latinburger.repository.CategoriaRepository;
import com.latinburger.repository.ColorRepository;
import com.latinburger.repository.TipoDecoracionRepository;
import com.latinburger.repository.TipoEventoRepository;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Catálogos que el cliente ve al armar su reserva: tipos de evento, decoraciones, colores
 * y categorías del menú (antes TipoEventoDAO, TipoDecoracionDAO, ColorDAO y CategoriaDAO).
 */
@Service
@Transactional(readOnly = true)
public class CatalogoService {

    private final TipoEventoRepository tipoEventoRepository;
    private final TipoDecoracionRepository tipoDecoracionRepository;
    private final ColorRepository colorRepository;
    private final CategoriaRepository categoriaRepository;

    public CatalogoService(TipoEventoRepository tipoEventoRepository,
                           TipoDecoracionRepository tipoDecoracionRepository,
                           ColorRepository colorRepository,
                           CategoriaRepository categoriaRepository) {
        this.tipoEventoRepository = tipoEventoRepository;
        this.tipoDecoracionRepository = tipoDecoracionRepository;
        this.colorRepository = colorRepository;
        this.categoriaRepository = categoriaRepository;
    }

    // --------------------------- tipo_evento ---------------------------

    public List<TipoEvento> listarEventos() {
        return tipoEventoRepository.findByActivoTrueOrderByNombreEventoAsc();
    }

    public List<TipoEvento> listarTodosEventos() {
        return tipoEventoRepository.findAllByOrderByNombreEventoAsc();
    }

    public TipoEvento consultarTipoEvento(int id) {
        return tipoEventoRepository.findById(id).orElse(null);
    }

    /** Inserta (id = 0) o actualiza nombre, descripción, valor e imagen sin tocar "activo". */
    @Transactional
    public void guardarTipoEvento(TipoEvento datos) {
        if (datos.getIdTipoEvento() == 0) {
            datos.setActivo(true);
            tipoEventoRepository.save(datos);
            return;
        }
        tipoEventoRepository.findById(datos.getIdTipoEvento()).ifPresent(te -> {
            te.setNombreEvento(datos.getNombreEvento());
            te.setDescripcion(datos.getDescripcion());
            te.setValorEvento(datos.getValorEvento());
            te.setImagen(datos.getImagen());
        });
    }

    @Transactional
    public boolean eliminarTipoEvento(int id) {
        if (!tipoEventoRepository.existsById(id)) {
            return false;
        }
        tipoEventoRepository.deleteById(id);
        return true;
    }

    @Transactional
    public boolean cambiarActivoEvento(int id, boolean activo) {
        return tipoEventoRepository.cambiarActivo(id, activo) > 0;
    }

    // ------------------------- tipo_decoracion -------------------------

    public List<TipoDecoracion> listarDecoraciones() {
        return tipoDecoracionRepository.findByActivoTrueOrderByNombreDecoracionAsc();
    }

    public List<TipoDecoracion> listarTodasDecoraciones() {
        return tipoDecoracionRepository.findAllByOrderByNombreDecoracionAsc();
    }

    public TipoDecoracion consultarTipoDecoracion(int id) {
        return tipoDecoracionRepository.findById(id).orElse(null);
    }

    @Transactional
    public void guardarTipoDecoracion(TipoDecoracion datos) {
        if (datos.getIdTipoDecoracion() == 0) {
            datos.setActivo(true);
            tipoDecoracionRepository.save(datos);
            return;
        }
        tipoDecoracionRepository.findById(datos.getIdTipoDecoracion()).ifPresent(td -> {
            td.setNombreDecoracion(datos.getNombreDecoracion());
            td.setDescripcion(datos.getDescripcion());
            td.setValorDecoracion(datos.getValorDecoracion());
            td.setImagen(datos.getImagen());
        });
    }

    @Transactional
    public boolean eliminarTipoDecoracion(int id) {
        if (!tipoDecoracionRepository.existsById(id)) {
            return false;
        }
        tipoDecoracionRepository.deleteById(id);
        return true;
    }

    @Transactional
    public boolean cambiarActivoDecoracion(int id, boolean activo) {
        return tipoDecoracionRepository.cambiarActivo(id, activo) > 0;
    }

    // --------------------------- color_evento --------------------------

    public List<Color> listarColores() {
        return colorRepository.findByActivoTrueOrderByNombreAsc();
    }

    public List<Color> listarTodosColores() {
        return colorRepository.findAllByOrderByNombreAsc();
    }

    public Color consultarColor(int id) {
        return colorRepository.findById(id).orElse(null);
    }

    /** ColorDAO.consultarPorNombre (la reserva guarda el nombre del color, no su id). */
    public Color consultarColorPorNombre(String nombre) {
        if (nombre == null || nombre.trim().isEmpty()) {
            return null;
        }
        return colorRepository.findFirstByNombre(nombre).orElse(null);
    }

    @Transactional
    public void guardarColor(Color datos) {
        if (datos.getIdColor() == 0) {
            datos.setActivo(true);
            colorRepository.save(datos);
            return;
        }
        colorRepository.findById(datos.getIdColor()).ifPresent(c -> {
            c.setNombre(datos.getNombre());
            c.setCodigoHex(datos.getCodigoHex());
            c.setImagen(datos.getImagen());
        });
    }

    @Transactional
    public boolean cambiarActivoColor(int id, boolean activo) {
        return colorRepository.cambiarActivo(id, activo) > 0;
    }

    // ---------------------------- Categoria ----------------------------

    /** CategoriaDAO.listar (SELECT * FROM Categoria). */
    public List<Categoria> listarCategorias() {
        return categoriaRepository.findAll();
    }

    /** Categorías ORDER BY id_categoria (filtros del menú del cliente). */
    public List<Categoria> listarCategoriasOrdenadas() {
        return categoriaRepository.findAllByOrderByIdCategoriaAsc();
    }

    /** id_categoria -> nombre; reemplaza el bucle que hacían Menu.jsp y ReservaForm.jsp. */
    public Map<Integer, String> nombresCategoria() {
        Map<Integer, String> nombres = new LinkedHashMap<>();
        for (Categoria c : categoriaRepository.findAll()) {
            nombres.put(c.getIdCategoria(), c.getNombre());
        }
        return nombres;
    }
}
