package com.latinburger.service;

import com.latinburger.entity.Producto;
import com.latinburger.repository.ProductoRepository;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/** Productos / platos del menú (antes ProductoDAO y la consulta interna de MenuServlet). */
@Service
@Transactional(readOnly = true)
public class ProductoService {

    private final ProductoRepository productoRepository;

    public ProductoService(ProductoRepository productoRepository) {
        this.productoRepository = productoRepository;
    }

    /** ProductoDAO.listar: solo platos activos. */
    public List<Producto> listar() {
        return productoRepository.findByActivoTrue();
    }

    /** ProductoDAO.listarPorCategoria */
    public List<Producto> listarPorCategoria(int idCategoria) {
        return productoRepository.findByIdCategoriaAndActivoTrue(idCategoria);
    }

    /** ProductoDAO.listarTodos (incluye ocultos, para el administrador). */
    public List<Producto> listarTodos() {
        return productoRepository.findAllByOrderByIdCategoriaAscNombreAsc();
    }

    public Producto consultar(int idProducto) {
        return productoRepository.findById(idProducto).orElse(null);
    }

    /** Inserta (id = 0, activo = 1) o actualiza nombre, descripción, precio, categoría e imagen. */
    @Transactional
    public void guardar(Producto datos) {
        if (datos.getIdProducto() == 0) {
            datos.setActivo(true);
            productoRepository.save(datos);
            return;
        }
        productoRepository.findById(datos.getIdProducto()).ifPresent(p -> {
            p.setNombre(datos.getNombre());
            p.setDescripcion(datos.getDescripcion());
            p.setPrecio(datos.getPrecio());
            p.setIdCategoria(datos.getIdCategoria());
            p.setImagen(datos.getImagen());
        });
    }

    /** ProductoDAO.cambiarActivo (ocultar / mostrar). */
    @Transactional
    public boolean cambiarActivo(int idProducto, boolean activo) {
        return productoRepository.cambiarActivo(idProducto, activo) > 0;
    }

    /**
     * Menú del cliente (MenuServlet.obtenerListaMenu): lista de mapas con las claves
     * id, nombre, descripcion, precio ("%.0f"), idCategoria, categoria, imagen.
     * Los precios salen siempre de la base de datos, nunca del navegador.
     */
    public List<Map<String, String>> obtenerListaMenu() {
        List<Map<String, String>> listaMenu = new ArrayList<>();
        for (Object[] fila : productoRepository.listarMenuConCategoria()) {
            Producto p = (Producto) fila[0];
            Map<String, String> plato = new HashMap<>();
            plato.put("id", String.valueOf(p.getIdProducto()));
            plato.put("nombre", p.getNombre());
            plato.put("descripcion", p.getDescripcion());
            plato.put("precio", String.format("%.0f", p.getPrecio()));
            plato.put("idCategoria", String.valueOf(p.getIdCategoria()));
            plato.put("categoria", (String) fila[1]);
            plato.put("imagen", p.getImagen());
            listaMenu.add(plato);
        }
        return listaMenu;
    }
}
