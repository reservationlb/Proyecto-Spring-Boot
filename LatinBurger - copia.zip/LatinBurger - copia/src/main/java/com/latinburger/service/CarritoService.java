package com.latinburger.service;

import com.latinburger.dto.ItemCarrito;
import com.latinburger.entity.Producto;
import com.latinburger.entity.ReservaProducto;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Interpreta el campo "carritoData" que arma el JavaScript de las vistas
 * con el formato "id:cantidad,id:cantidad,...".
 */
@Service
@Transactional(readOnly = true)
public class CarritoService {

    private final ProductoService productoService;

    public CarritoService(ProductoService productoService) {
        this.productoService = productoService;
    }

    /**
     * Carrito del cliente (MenuServlet.doPost): ignora pares mal formados, cantidades &lt;= 0 y
     * productos que no estén activos en el menú; el precio se toma de la base de datos.
     */
    public List<ItemCarrito> parsearCarritoCliente(String carritoData) {
        List<ItemCarrito> carrito = new ArrayList<>();
        if (carritoData == null || carritoData.trim().isEmpty()) {
            return carrito;
        }
        Map<String, Map<String, String>> platosPorId = new HashMap<>();
        for (Map<String, String> plato : productoService.obtenerListaMenu()) {
            platosPorId.put(plato.get("id"), plato);
        }
        for (String parItem : carritoData.split(",")) {
            String[] partes = parItem.split(":");
            if (partes.length != 2) {
                continue;
            }
            String idProducto = partes[0].trim();
            int cantidad;
            try {
                cantidad = Integer.parseInt(partes[1].trim());
            } catch (NumberFormatException e) {
                continue;
            }
            if (cantidad <= 0 || !platosPorId.containsKey(idProducto)) {
                continue;
            }
            Map<String, String> plato = platosPorId.get(idProducto);
            carrito.add(new ItemCarrito(Integer.parseInt(idProducto), plato.get("nombre"),
                    new BigDecimal(plato.get("precio")), cantidad));
        }
        return carrito;
    }

    /**
     * Carrito del pedido registrado por el administrador (AdminReservaFormServlet):
     * un número inválido lanza NumberFormatException, igual que en el Servlet original.
     */
    public List<ReservaProducto> parsearCarritoAdmin(String carritoData) {
        List<ReservaProducto> items = new ArrayList<>();
        if (carritoData == null || carritoData.trim().isEmpty()) {
            return items;
        }
        for (String par : carritoData.split(",")) {
            String[] partes = par.split(":");
            if (partes.length != 2) {
                continue;
            }
            int idProducto = Integer.parseInt(partes[0].trim());
            int cantidad = Integer.parseInt(partes[1].trim());
            if (cantidad <= 0) {
                continue;
            }
            Producto p = productoService.consultar(idProducto);
            if (p == null) {
                continue;
            }
            ReservaProducto rp = new ReservaProducto();
            rp.setProductoIdProducto(idProducto);
            rp.setCantidad(cantidad);
            rp.setPrecioUnitario(BigDecimal.valueOf(p.getPrecio()));
            items.add(rp);
        }
        return items;
    }

    /** Convierte el carrito de sesión en filas de reserva_producto. */
    public List<ReservaProducto> aDetalle(List<ItemCarrito> carrito) {
        List<ReservaProducto> items = new ArrayList<>();
        for (ItemCarrito item : carrito) {
            ReservaProducto rp = new ReservaProducto();
            rp.setProductoIdProducto(item.getIdProducto());
            rp.setCantidad(item.getCantidad());
            rp.setPrecioUnitario(item.getPrecioUnitario());
            items.add(rp);
        }
        return items;
    }

    public BigDecimal totalCarrito(List<ItemCarrito> carrito) {
        BigDecimal total = BigDecimal.ZERO;
        for (ItemCarrito item : carrito) {
            total = total.add(item.getSubtotal());
        }
        return total;
    }

    public BigDecimal totalDetalle(List<ReservaProducto> items) {
        BigDecimal total = BigDecimal.ZERO;
        for (ReservaProducto item : items) {
            total = total.add(item.getSubtotal());
        }
        return total;
    }
}
