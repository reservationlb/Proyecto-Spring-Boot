package com.latinburger.service;

import com.latinburger.config.SesionKeys;
import com.latinburger.entity.Reserva;
import com.latinburger.entity.Usuario;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/** Datos del comprobante de una reserva (antes FacturaServlet). */
@Service
@Transactional(readOnly = true)
public class FacturaService {

    private final ReservaService reservaService;
    private final CatalogoService catalogoService;
    private final UsuarioService usuarioService;
    private final ReservaProductoService reservaProductoService;
    private final AbonoService abonoService;

    public FacturaService(ReservaService reservaService, CatalogoService catalogoService,
                          UsuarioService usuarioService, ReservaProductoService reservaProductoService,
                          AbonoService abonoService) {
        this.reservaService = reservaService;
        this.catalogoService = catalogoService;
        this.usuarioService = usuarioService;
        this.reservaProductoService = reservaProductoService;
        this.abonoService = abonoService;
    }

    /** Un cliente solo puede ver sus propias facturas; el administrador (rol 1) puede ver cualquiera. */
    public boolean puedeVer(Usuario usuarioSesion, Reserva reserva) {
        return usuarioSesion.getRolIdRol() == SesionKeys.ROL_ADMINISTRADOR
                || reserva.getUsuarioIdUsuario() == usuarioSesion.getIdUsuario();
    }

    /** Atributos de la vista: reserva, evento, decoracion, cliente, items, abonos. */
    public Map<String, Object> datosFactura(Reserva reserva) {
        int idReserva = reserva.getIdReserva();
        Map<String, Object> datos = new HashMap<>();
        datos.put("reserva", reserva);
        datos.put("evento", catalogoService.consultarTipoEvento(reserva.getTipoEventoIdTipoEvento()));
        datos.put("decoracion", catalogoService.consultarTipoDecoracion(reserva.getTipoDecoracionIdTipoDecoracion()));
        datos.put("cliente", usuarioService.consultarPorId(reserva.getUsuarioIdUsuario()));
        datos.put("items", reservaProductoService.listarPorReserva(idReserva));
        datos.put("abonos", abonoService.listarPorReserva(idReserva));
        return datos;
    }

    public Reserva consultarReserva(int idReserva) {
        return reservaService.consultarReserva(idReserva);
    }
}
