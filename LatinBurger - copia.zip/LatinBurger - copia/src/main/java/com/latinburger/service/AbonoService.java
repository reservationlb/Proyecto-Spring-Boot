package com.latinburger.service;

import com.latinburger.entity.Abono;
import com.latinburger.repository.AbonoRepository;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/** Abonos / pagos de una reserva (antes AbonoDAO). */
@Service
@Transactional(readOnly = true)
public class AbonoService {

    private final AbonoRepository abonoRepository;

    public AbonoService(AbonoRepository abonoRepository) {
        this.abonoRepository = abonoRepository;
    }

    /** AbonoDAO.insertar: estado por defecto 'Registrado'; fecha_abono la asigna MySQL. */
    @Transactional
    public Abono insertar(Abono abono) {
        if (abono.getEstado() == null) {
            abono.setEstado("Registrado");
        }
        return abonoRepository.save(abono);
    }

    /** AbonoDAO.listarPorReserva */
    public List<Abono> listarPorReserva(int idReserva) {
        return abonoRepository.findByReservaIdReservaOrderByFechaAbonoDesc(idReserva);
    }

    /** Suma de los abonos de una lista (panel del cliente). */
    public BigDecimal totalAbonado(List<Abono> abonos) {
        BigDecimal total = BigDecimal.ZERO;
        for (Abono a : abonos) {
            if (a.getValorAbono() != null) {
                total = total.add(a.getValorAbono());
            }
        }
        return total;
    }

    /**
     * AbonoDAO.listarTodos (panel de administrador -> Abonos): mapas con las claves
     * id_abono, medio_pago, valor_abono, fecha_abono, estado, id_reserva, fecha_evento, cliente.
     */
    public List<Map<String, String>> listarTodos() {
        List<Map<String, String>> lista = new ArrayList<>();
        for (Object[] fila : abonoRepository.listarTodosConDetalle()) {
            Abono a = (Abono) fila[0];
            LocalDateTime fechaAbono = a.getFechaAbono();
            Map<String, String> m = new HashMap<>();
            m.put("id_abono", String.valueOf(a.getIdAbono()));
            m.put("medio_pago", a.getMedioPago());
            m.put("valor_abono", String.format("%,.0f", a.getValorAbono() != null ? a.getValorAbono().doubleValue() : 0d));
            m.put("fecha_abono", fechaAbono != null ? Timestamp.valueOf(fechaAbono).toString() : "null");
            m.put("estado", a.getEstado());
            m.put("id_reserva", String.valueOf(fila[1]));
            m.put("fecha_evento", String.valueOf((LocalDate) fila[2]));
            m.put("cliente", fila[3] + " " + fila[4]);
            lista.add(m);
        }
        return lista;
    }

    /** AbonoDAO.sumarAbonosMes */
    public double sumarAbonosMes(int anio, int mes) {
        Number total = abonoRepository.sumarAbonosMes(anio, mes);
        return total != null ? total.doubleValue() : 0d;
    }
}
