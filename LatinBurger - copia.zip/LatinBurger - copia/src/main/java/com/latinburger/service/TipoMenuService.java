package com.latinburger.service;

import com.latinburger.entity.TipoMenu;
import com.latinburger.repository.TipoMenuRepository;
import java.util.List;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/** Tipos de menú (antes TipoMenuDAO). */
@Service
@Transactional(readOnly = true)
public class TipoMenuService {

    /** Nombre del tipo de menú que se asigna a las reservas armadas plato a plato. */
    public static final String MENU_PERSONALIZADO = "Menú personalizado";

    /** Id que usaban los Servlets cuando no existía el menú personalizado. */
    public static final int ID_MENU_POR_DEFECTO = 10;

    private final TipoMenuRepository tipoMenuRepository;

    public TipoMenuService(TipoMenuRepository tipoMenuRepository) {
        this.tipoMenuRepository = tipoMenuRepository;
    }

    /**
     * TipoMenuDAO.buscarPersonalizado: busca "Menú personalizado"; si no existe,
     * devuelve el tipo de menú con id 1 (o null si tampoco existe).
     */
    public TipoMenu buscarPersonalizado() {
        return tipoMenuRepository.findFirstByNombreMenu(MENU_PERSONALIZADO)
                .orElseGet(() -> tipoMenuRepository.findById(1).orElse(null));
    }

    /** Id de tipo_menu a guardar en una reserva nueva (misma regla de los Servlets). */
    public int idMenuParaReserva() {
        TipoMenu personalizado = buscarPersonalizado();
        return personalizado != null ? personalizado.getIdTipoMenu() : ID_MENU_POR_DEFECTO;
    }

    public List<TipoMenu> listar() {
        return tipoMenuRepository.findAll();
    }

    public TipoMenu consultarTipoMenu(int id) {
        return tipoMenuRepository.findById(id).orElse(null);
    }

    @Transactional
    public boolean insertarTipoMenu(TipoMenu menu) {
        menu.setIdTipoMenu(0);
        tipoMenuRepository.save(menu);
        return true;
    }

    @Transactional
    public boolean actualizarTipoMenu(TipoMenu menu) {
        if (!tipoMenuRepository.existsById(menu.getIdTipoMenu())) {
            return false;
        }
        tipoMenuRepository.save(menu);
        return true;
    }

    @Transactional
    public boolean eliminarTipoMenu(int id) {
        if (!tipoMenuRepository.existsById(id)) {
            return false;
        }
        tipoMenuRepository.deleteById(id);
        return true;
    }
}
