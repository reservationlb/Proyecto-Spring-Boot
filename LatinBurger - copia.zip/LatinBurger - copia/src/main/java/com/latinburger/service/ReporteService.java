package com.latinburger.service;

import java.time.LocalDate;
import java.time.format.TextStyle;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/** Métricas del dashboard y de la sección de reportes (antes AdminDashboardServlet y AdminReportesServlet). */
@Service
@Transactional(readOnly = true)
public class ReporteService {

    private static final Locale ESPANOL = Locale.forLanguageTag("es-ES");

    private final ReservaService reservaService;
    private final ReservaProductoService reservaProductoService;

    public ReporteService(ReservaService reservaService, ReservaProductoService reservaProductoService) {
        this.reservaService = reservaService;
        this.reservaProductoService = reservaProductoService;
    }

    /** pedidosHoy, ventasHoy, pendientes y ultimosPedidos (máximo 6). */
    public Map<String, Object> datosDashboard() {
        Map<String, Object> datos = new HashMap<>();
        datos.put("pedidosHoy", reservaService.contarReservasHoy());
        datos.put("ventasHoy", reservaService.sumarValorHoy());
        datos.put("pendientes", reservaService.contarReservasPendientes());
        List<Map<String, String>> todas = reservaService.listarTodasConDetalle();
        datos.put("ultimosPedidos", todas.size() > 6 ? new ArrayList<>(todas.subList(0, 6)) : todas);
        return datos;
    }

    /** pedidosEsteMes, ventasEsteMes, ventasPorMes (últimos 4 meses) y popularidad (top 6 platos). */
    public Map<String, Object> datosReportes() {
        LocalDate hoy = LocalDate.now();
        Map<String, Object> datos = new HashMap<>();
        datos.put("pedidosEsteMes", reservaService.contarReservasMes(hoy.getYear(), hoy.getMonthValue()));
        datos.put("ventasEsteMes", reservaService.sumarValorMes(hoy.getYear(), hoy.getMonthValue()));

        List<Map<String, String>> ventasPorMes = new ArrayList<>();
        for (int i = 3; i >= 0; i--) {
            LocalDate mes = hoy.minusMonths(i);
            double valor = reservaService.sumarValorMes(mes.getYear(), mes.getMonthValue());
            Map<String, String> fila = new HashMap<>();
            fila.put("mes", mes.getMonth().getDisplayName(TextStyle.FULL, ESPANOL));
            fila.put("valor", String.format("%,.0f", valor));
            ventasPorMes.add(fila);
        }
        datos.put("ventasPorMes", ventasPorMes);
        datos.put("popularidad", reservaProductoService.popularidadPlatos(6));
        return datos;
    }
}
