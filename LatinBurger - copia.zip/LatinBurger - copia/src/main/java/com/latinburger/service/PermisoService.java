package com.latinburger.service;

import com.latinburger.entity.Permiso;
import com.latinburger.entity.PermisoHasRol;
import com.latinburger.entity.PermisoHasRolId;
import com.latinburger.repository.PermisoHasRolRepository;
import com.latinburger.repository.PermisoRepository;
import java.util.List;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/** Gestión de permisos y de su asignación a roles (antes PermisoDAO y PermisoHasRolDAO). */
@Service
@Transactional(readOnly = true)
public class PermisoService {

    private final PermisoRepository permisoRepository;
    private final PermisoHasRolRepository permisoHasRolRepository;

    public PermisoService(PermisoRepository permisoRepository, PermisoHasRolRepository permisoHasRolRepository) {
        this.permisoRepository = permisoRepository;
        this.permisoHasRolRepository = permisoHasRolRepository;
    }

    // ----------------------------- permiso -----------------------------

    public List<Permiso> listar() {
        return permisoRepository.findAll();
    }

    public Permiso consultarPermiso(int idPermiso) {
        return permisoRepository.findById(idPermiso).orElse(null);
    }

    @Transactional
    public boolean insertarPermiso(Permiso permiso) {
        permiso.setIdPermiso(0);
        permisoRepository.save(permiso);
        return true;
    }

    @Transactional
    public boolean actualizarPermiso(Permiso permiso) {
        if (!permisoRepository.existsById(permiso.getIdPermiso())) {
            return false;
        }
        permisoRepository.save(permiso);
        return true;
    }

    @Transactional
    public boolean eliminarPermiso(int idPermiso) {
        if (!permisoRepository.existsById(idPermiso)) {
            return false;
        }
        permisoRepository.deleteById(idPermiso);
        return true;
    }

    // ------------------------- permiso_has_rol -------------------------

    public List<PermisoHasRol> listarPorRol(int idRol) {
        return permisoHasRolRepository.findByRolIdRol(idRol);
    }

    public PermisoHasRol consultarPermisoHasRol(int permisoId, int rolId) {
        return permisoHasRolRepository.findById(new PermisoHasRolId(permisoId, rolId)).orElse(null);
    }

    @Transactional
    public boolean insertarPermisoHasRol(PermisoHasRol relacion) {
        PermisoHasRolId id = new PermisoHasRolId(relacion.getPermisoIdPermiso(), relacion.getRolIdRol());
        if (permisoHasRolRepository.existsById(id)) {
            return false;
        }
        permisoHasRolRepository.save(relacion);
        return true;
    }

    @Transactional
    public boolean eliminarPermisoHasRol(int permisoId, int rolId) {
        PermisoHasRolId id = new PermisoHasRolId(permisoId, rolId);
        if (!permisoHasRolRepository.existsById(id)) {
            return false;
        }
        permisoHasRolRepository.deleteById(id);
        return true;
    }
}
