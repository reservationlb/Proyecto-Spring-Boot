package com.latinburger.service;

import com.latinburger.entity.TipoDocumento;
import com.latinburger.repository.TipoDocumentoRepository;
import java.util.List;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/** Tipos de documento (antes TipoDocumentoDAO). */
@Service
@Transactional(readOnly = true)
public class TipoDocumentoService {

    private final TipoDocumentoRepository tipoDocumentoRepository;

    public TipoDocumentoService(TipoDocumentoRepository tipoDocumentoRepository) {
        this.tipoDocumentoRepository = tipoDocumentoRepository;
    }

    public List<TipoDocumento> listar() {
        return tipoDocumentoRepository.findAll();
    }

    public TipoDocumento consultarTipoDocumento(int id) {
        return tipoDocumentoRepository.findById(id).orElse(null);
    }

    /** El id se inserta explícitamente, igual que en TipoDocumentoDAO.insertarTipoDocumento. */
    @Transactional
    public boolean insertarTipoDocumento(TipoDocumento tipo) {
        if (tipoDocumentoRepository.existsById(tipo.getIdTipoDocumento())) {
            return false;
        }
        tipoDocumentoRepository.save(tipo);
        return true;
    }

    @Transactional
    public boolean actualizarTipoDocumento(TipoDocumento tipo) {
        if (!tipoDocumentoRepository.existsById(tipo.getIdTipoDocumento())) {
            return false;
        }
        tipoDocumentoRepository.save(tipo);
        return true;
    }

    @Transactional
    public boolean eliminarTipoDocumento(int id) {
        if (!tipoDocumentoRepository.existsById(id)) {
            return false;
        }
        tipoDocumentoRepository.deleteById(id);
        return true;
    }
}
