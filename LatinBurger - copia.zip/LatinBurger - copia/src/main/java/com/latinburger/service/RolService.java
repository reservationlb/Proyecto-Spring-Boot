package com.latinburger.service;

import com.latinburger.entity.Rol;
import com.latinburger.repository.RolRepository;
import java.util.List;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/** Gestión de roles (antes RolDAO). */
@Service
@Transactional(readOnly = true)
public class RolService {

    private final RolRepository rolRepository;

    public RolService(RolRepository rolRepository) {
        this.rolRepository = rolRepository;
    }

    /** RolDAO.listar: solo roles activos, ordenados por descripción. */
    public List<Rol> listar() {
        return rolRepository.findByEstadoOrderByDescripcionAsc("Activo");
    }

    public List<Rol> listarTodos() {
        return rolRepository.findAll();
    }

    public Rol consultarRol(int idRol) {
        return rolRepository.findById(idRol).orElse(null);
    }

    @Transactional
    public boolean insertarRol(Rol rol) {
        rol.setIdRol(0);
        rolRepository.save(rol);
        return true;
    }

    @Transactional
    public boolean actualizarRol(Rol rol) {
        if (!rolRepository.existsById(rol.getIdRol())) {
            return false;
        }
        rolRepository.save(rol);
        return true;
    }

    @Transactional
    public boolean inactivarRol(int idRol) {
        return rolRepository.cambiarEstado(idRol, "Inactivo") > 0;
    }

    @Transactional
    public boolean activarRol(int idRol) {
        return rolRepository.cambiarEstado(idRol, "Activo") > 0;
    }

    @Transactional
    public boolean eliminarRol(int idRol) {
        if (!rolRepository.existsById(idRol)) {
            return false;
        }
        rolRepository.deleteById(idRol);
        return true;
    }
}
