package com.latinburger.service;

import com.latinburger.entity.Abono;
import com.latinburger.entity.Reserva;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Arma las tarjetas del panel del cliente (antes PanelClienteServlet). Un cliente solo ve
 * SUS reservas: la consulta filtra por usuario_id_usuario = id del usuario en sesión.
 */
@Service
@Transactional(readOnly = true)
public class PanelClienteService {

    private final ReservaService reservaService;
    private final CatalogoService catalogoService;
    private final TipoMenuService tipoMenuService;
    private final ReservaProductoService reservaProductoService;
    private final AbonoService abonoService;

    public PanelClienteService(ReservaService reservaService, CatalogoService catalogoService,
                               TipoMenuService tipoMenuService, ReservaProductoService reservaProductoService,
                               AbonoService abonoService) {
        this.reservaService = reservaService;
        this.catalogoService = catalogoService;
        this.tipoMenuService = tipoMenuService;
        this.reservaProductoService = reservaProductoService;
        this.abonoService = abonoService;
    }

    /**
     * Cada tarjeta contiene: reserva, evento, decoracion, tipoMenu, color, productos,
     * abonos, totalAbonado y saldoPendiente (nunca negativo).
     */
    public List<Map<String, Object>> tarjetas(int idUsuario) {
        List<Map<String, Object>> tarjetas = new ArrayList<>();
        for (Reserva r : reservaService.listarPorUsuarioCompleta(idUsuario)) {
            List<Abono> abonos = abonoService.listarPorReserva(r.getIdReserva());
            BigDecimal totalAbonado = abonoService.totalAbonado(abonos);
            BigDecimal valorReserva = r.getValorReserva() != null ? r.getValorReserva() : BigDecimal.ZERO;
            BigDecimal saldoPendiente = valorReserva.subtract(totalAbonado);
            if (saldoPendiente.compareTo(BigDecimal.ZERO) < 0) {
                saldoPendiente = BigDecimal.ZERO;
            }

            Map<String, Object> tarjeta = new HashMap<>();
            tarjeta.put("reserva", r);
            tarjeta.put("evento", catalogoService.consultarTipoEvento(r.getTipoEventoIdTipoEvento()));
            tarjeta.put("decoracion", catalogoService.consultarTipoDecoracion(r.getTipoDecoracionIdTipoDecoracion()));
            tarjeta.put("tipoMenu", tipoMenuService.consultarTipoMenu(r.getTipoMenuIdTipoMenu()));
            tarjeta.put("color", catalogoService.consultarColorPorNombre(r.getColorEvento()));
            tarjeta.put("productos", reservaProductoService.listarPorReserva(r.getIdReserva()));
            tarjeta.put("abonos", abonos);
            tarjeta.put("totalAbonado", totalAbonado);
            tarjeta.put("saldoPendiente", saldoPendiente);
            tarjetas.add(tarjeta);
        }
        return tarjetas;
    }
}
