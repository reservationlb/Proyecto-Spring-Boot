package com.latinburger;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Punto de entrada de Reservation L.B. (Latin Burger) sobre Spring Boot.
 * Reemplaza el despliegue WAR en GlassFish del proyecto NetBeans/Ant original.
 */
@SpringBootApplication
public class LatinBurgerApplication {

    public static void main(String[] args) {
        SpringApplication.run(LatinBurgerApplication.class, args);
    }
}
