package com.latinburger.repository;

import com.latinburger.entity.TipoEvento;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/** Migración de TipoEventoDAO. */
@Repository
public interface TipoEventoRepository extends JpaRepository<TipoEvento, Integer> {

    /** TipoEventoDAO.listar: solo activos (lo que ve el cliente). */
    List<TipoEvento> findByActivoTrueOrderByNombreEventoAsc();

    /** TipoEventoDAO.listarTodos: incluye ocultos (panel de administrador). */
    List<TipoEvento> findAllByOrderByNombreEventoAsc();

    /** TipoEventoDAO.cambiarActivo (ocultar / mostrar). */
    @Modifying
    @Query("UPDATE TipoEvento t SET t.activo = :activo WHERE t.idTipoEvento = :id")
    int cambiarActivo(@Param("id") int id, @Param("activo") boolean activo);
}
