package com.latinburger.repository;

import com.latinburger.entity.TipoDecoracion;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/** Migración de TipoDecoracionDAO. */
@Repository
public interface TipoDecoracionRepository extends JpaRepository<TipoDecoracion, Integer> {

    /** TipoDecoracionDAO.listar: solo activos (lo que ve el cliente). */
    List<TipoDecoracion> findByActivoTrueOrderByNombreDecoracionAsc();

    /** TipoDecoracionDAO.listarTodos: incluye ocultos (panel de administrador). */
    List<TipoDecoracion> findAllByOrderByNombreDecoracionAsc();

    /** TipoDecoracionDAO.cambiarActivo (ocultar / mostrar). */
    @Modifying
    @Query("UPDATE TipoDecoracion t SET t.activo = :activo WHERE t.idTipoDecoracion = :id")
    int cambiarActivo(@Param("id") int id, @Param("activo") boolean activo);
}
