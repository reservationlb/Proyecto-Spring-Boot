package com.latinburger.repository;

import com.latinburger.entity.Rol;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/** Migración de RolDAO. */
@Repository
public interface RolRepository extends JpaRepository<Rol, Integer> {

    /** RolDAO.listar: WHERE estado = 'Activo' ORDER BY descripcion. */
    List<Rol> findByEstadoOrderByDescripcionAsc(String estado);

    /** RolDAO.activarRol / inactivarRol */
    @Modifying
    @Query("UPDATE Rol r SET r.estado = :estado WHERE r.idRol = :id")
    int cambiarEstado(@Param("id") int idRol, @Param("estado") String estado);
}
