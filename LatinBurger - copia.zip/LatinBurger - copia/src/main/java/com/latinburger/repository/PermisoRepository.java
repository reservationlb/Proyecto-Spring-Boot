package com.latinburger.repository;

import com.latinburger.entity.Permiso;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/** Migración de PermisoDAO (consultar, insertar, actualizar, eliminar). */
@Repository
public interface PermisoRepository extends JpaRepository<Permiso, Integer> {
}
