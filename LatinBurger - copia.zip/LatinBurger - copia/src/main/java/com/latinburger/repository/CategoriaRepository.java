package com.latinburger.repository;

import com.latinburger.entity.Categoria;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/** Migración de CategoriaDAO (SELECT * FROM Categoria). */
@Repository
public interface CategoriaRepository extends JpaRepository<Categoria, Integer> {

    /** Usado por el menú del cliente: ORDER BY id_categoria. */
    List<Categoria> findAllByOrderByIdCategoriaAsc();
}
