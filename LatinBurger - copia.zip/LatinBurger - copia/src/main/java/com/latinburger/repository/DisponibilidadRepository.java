package com.latinburger.repository;

import com.latinburger.entity.Disponibilidad;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/** Migración de DisponibilidadDAO. */
@Repository
public interface DisponibilidadRepository extends JpaRepository<Disponibilidad, Integer> {

    /** DisponibilidadDAO.listarDisponibles(fecha) con filtro de fecha. */
    @Query("SELECT d FROM Disponibilidad d WHERE d.fecha = :fecha AND d.estado = 'Disponible' "
            + "AND d.fecha >= CURRENT_DATE ORDER BY d.hora ASC")
    List<Disponibilidad> listarDisponiblesPorFecha(@Param("fecha") LocalDate fecha);

    /** DisponibilidadDAO.listarDisponibles(null): todas las futuras disponibles. */
    @Query("SELECT d FROM Disponibilidad d WHERE d.estado = 'Disponible' AND d.fecha >= CURRENT_DATE "
            + "ORDER BY d.fecha ASC, d.hora ASC")
    List<Disponibilidad> listarDisponibles();

    /** DisponibilidadDAO.listarTodas: ORDER BY fecha DESC, hora ASC. */
    List<Disponibilidad> findAllByOrderByFechaDescHoraAsc();

    /** DisponibilidadDAO.consultarPorFechaYHora (solo estado 'Disponible'). */
    Optional<Disponibilidad> findFirstByFechaAndHoraAndEstado(LocalDate fecha, LocalTime hora, String estado);

    /** Todas las filas de una fecha (diagnóstico cuando no hay coincidencia). */
    List<Disponibilidad> findByFecha(LocalDate fecha);

    /**
     * DisponibilidadDAO.ocuparDisponibilidad: el UPDATE condicionado a
     * estado = 'Disponible' garantiza que dos clientes no tomen el mismo horario.
     */
    @Modifying(flushAutomatically = true, clearAutomatically = true)
    @Query("UPDATE Disponibilidad d SET d.estado = 'Ocupado' WHERE d.idDisponibilidad = :id AND d.estado = 'Disponible'")
    int ocupar(@Param("id") int idDisponibilidad);

    /** DisponibilidadDAO.liberarDisponibilidad */
    @Modifying(flushAutomatically = true, clearAutomatically = true)
    @Query("UPDATE Disponibilidad d SET d.estado = 'Disponible' WHERE d.idDisponibilidad = :id")
    int liberar(@Param("id") int idDisponibilidad);

    /** DisponibilidadDAO.inactivarDisponibilidad */
    @Modifying(flushAutomatically = true, clearAutomatically = true)
    @Query("UPDATE Disponibilidad d SET d.estado = 'Inactivo' WHERE d.idDisponibilidad = :id")
    int inactivar(@Param("id") int idDisponibilidad);

    /** DisponibilidadDAO.activarDisponibilidad */
    @Modifying(flushAutomatically = true, clearAutomatically = true)
    @Query("UPDATE Disponibilidad d SET d.estado = 'Activo' WHERE d.idDisponibilidad = :id")
    int activar(@Param("id") int idDisponibilidad);
}
