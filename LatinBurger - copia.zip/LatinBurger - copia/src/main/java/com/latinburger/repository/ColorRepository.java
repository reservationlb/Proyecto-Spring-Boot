package com.latinburger.repository;

import com.latinburger.entity.Color;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/** Migración de ColorDAO (tabla color_evento). */
@Repository
public interface ColorRepository extends JpaRepository<Color, Integer> {

    /** ColorDAO.listar: solo activos, ORDER BY nombre. */
    List<Color> findByActivoTrueOrderByNombreAsc();

    /** ColorDAO.listarTodos: ORDER BY nombre. */
    List<Color> findAllByOrderByNombreAsc();

    /** ColorDAO.consultarPorNombre */
    Optional<Color> findFirstByNombre(String nombre);

    /** ColorDAO.cambiarActivo */
    @Modifying
    @Query("UPDATE Color c SET c.activo = :activo WHERE c.idColor = :id")
    int cambiarActivo(@Param("id") int idColor, @Param("activo") boolean activo);
}
