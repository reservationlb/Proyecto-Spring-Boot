package com.latinburger.repository;

import com.latinburger.entity.Reserva;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/** Migración de ReservaDAO. */
@Repository
public interface ReservaRepository extends JpaRepository<Reserva, Integer> {

    /**
     * ReservaDAO.listarPorUsuario (Mis Pedidos): reserva + tipo_evento + tipo_decoracion.
     * Cada fila: [Reserva, nombreEvento, nombreDecoracion].
     */
    @Query("SELECT r, te.nombreEvento, td.nombreDecoracion "
            + "FROM Reserva r, TipoEvento te, TipoDecoracion td "
            + "WHERE r.tipoEventoIdTipoEvento = te.idTipoEvento "
            + "AND r.tipoDecoracionIdTipoDecoracion = td.idTipoDecoracion "
            + "AND r.usuarioIdUsuario = :idUsuario ORDER BY r.fecha DESC, r.hora DESC")
    List<Object[]> listarPorUsuarioConDetalle(@Param("idUsuario") int idUsuario);

    /**
     * ReservaDAO.listarTodasConDetalle (admin): reserva + evento + decoración + usuario.
     * Cada fila: [Reserva, nombreEvento, nombreDecoracion, nombre, apellido].
     */
    @Query("SELECT r, te.nombreEvento, td.nombreDecoracion, u.nombre, u.apellido "
            + "FROM Reserva r, TipoEvento te, TipoDecoracion td, Usuario u "
            + "WHERE r.tipoEventoIdTipoEvento = te.idTipoEvento "
            + "AND r.tipoDecoracionIdTipoDecoracion = td.idTipoDecoracion "
            + "AND r.usuarioIdUsuario = u.idUsuario "
            + "ORDER BY r.fecha DESC, r.hora DESC")
    List<Object[]> listarTodasConDetalle();

    /** ReservaDAO.listarPorUsuarioCompleta */
    List<Reserva> findByUsuarioIdUsuarioOrderByFechaDescHoraDesc(int usuarioIdUsuario);

    /** ReservaDAO.actualizarEstado */
    @Modifying(flushAutomatically = true, clearAutomatically = true)
    @Query("UPDATE Reserva r SET r.estado = :estado WHERE r.idReserva = :id")
    int actualizarEstado(@Param("id") int idReserva, @Param("estado") String nuevoEstado);

    /** ReservaDAO.contarReservasHoy */
    @Query(value = "SELECT COUNT(*) AS total FROM reserva WHERE fecha = CURDATE() AND estado <> 'Cancelada'",
            nativeQuery = true)
    Number contarReservasHoy();

    /** ReservaDAO.sumarValorHoy */
    @Query(value = "SELECT COALESCE(SUM(valor_reserva), 0) AS total FROM reserva "
            + "WHERE fecha = CURDATE() AND estado <> 'Cancelada'", nativeQuery = true)
    Number sumarValorHoy();

    /** ReservaDAO.contarReservasPendientes */
    @Query(value = "SELECT COUNT(*) AS total FROM reserva WHERE estado = 'Pendiente'", nativeQuery = true)
    Number contarReservasPendientes();

    /** ReservaDAO.contarReservasMes (ahora con parámetros enlazados en lugar de concatenación). */
    @Query(value = "SELECT COUNT(*) AS total FROM reserva WHERE YEAR(fecha) = :anio "
            + "AND MONTH(fecha) = :mes AND estado <> 'Cancelada'", nativeQuery = true)
    Number contarReservasMes(@Param("anio") int anio, @Param("mes") int mes);

    /** ReservaDAO.sumarValorMes */
    @Query(value = "SELECT COALESCE(SUM(valor_reserva), 0) AS total FROM reserva "
            + "WHERE YEAR(fecha) = :anio AND MONTH(fecha) = :mes AND estado <> 'Cancelada'", nativeQuery = true)
    Number sumarValorMes(@Param("anio") int anio, @Param("mes") int mes);
}
