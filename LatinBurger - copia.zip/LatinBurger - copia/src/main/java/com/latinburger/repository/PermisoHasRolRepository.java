package com.latinburger.repository;

import com.latinburger.entity.PermisoHasRol;
import com.latinburger.entity.PermisoHasRolId;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/** Migración de PermisoHasRolDAO (clave compuesta permiso_id_permiso + rol_id_rol). */
@Repository
public interface PermisoHasRolRepository extends JpaRepository<PermisoHasRol, PermisoHasRolId> {

    List<PermisoHasRol> findByRolIdRol(int rolIdRol);
}
