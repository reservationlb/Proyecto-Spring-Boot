package com.latinburger.repository;

import com.latinburger.entity.ReservaProducto;
import java.util.List;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/** Migración de ReservaProductoDAO. */
@Repository
public interface ReservaProductoRepository extends JpaRepository<ReservaProducto, Integer> {

    /**
     * ReservaProductoDAO.listarPorReserva: reserva_producto INNER JOIN Producto.
     * Cada fila: [ReservaProducto, nombreProducto].
     */
    @Query("SELECT rp, p.nombre FROM ReservaProducto rp, Producto p "
            + "WHERE rp.productoIdProducto = p.idProducto AND rp.reservaIdReserva = :idReserva")
    List<Object[]> listarPorReservaConNombre(@Param("idReserva") int idReserva);

    /**
     * ReservaProductoDAO.popularidadPlatos(limite): el límite se aplica con Pageable.
     * Cada fila: [nombre, unidades, ingresos].
     */
    @Query("SELECT p.nombre, SUM(rp.cantidad), SUM(rp.cantidad * rp.precioUnitario) "
            + "FROM ReservaProducto rp, Producto p WHERE rp.productoIdProducto = p.idProducto "
            + "GROUP BY p.idProducto, p.nombre ORDER BY SUM(rp.cantidad) DESC")
    List<Object[]> popularidadPlatos(Pageable limite);
}
