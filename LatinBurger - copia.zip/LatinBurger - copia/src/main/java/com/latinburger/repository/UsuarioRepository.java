package com.latinburger.repository;

import com.latinburger.entity.Usuario;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/** Migración de UsuarioDAO. */
@Repository
public interface UsuarioRepository extends JpaRepository<Usuario, Integer> {

    /** UsuarioDAO.validarUsuario: WHERE documento = ? AND password = ?. */
    Optional<Usuario> findFirstByNumeroDocumentoAndContrasena(String numeroDocumento, String contrasena);

    /** UsuarioDAO.consultarUsuario: WHERE documento = ?. */
    Optional<Usuario> findFirstByNumeroDocumento(String numeroDocumento);

    /**
     * UsuarioDAO.listar: usuario INNER JOIN rol ORDER BY id_usuario.
     * Cada fila: [Usuario, descripcionRol].
     */
    @Query("SELECT u, r.descripcion FROM Usuario u, Rol r WHERE u.rolIdRol = r.idRol ORDER BY u.idUsuario")
    List<Object[]> listarConRol();

    /** UsuarioDAO.actualizarUsuario: solo nombre, apellido, dirección y teléfono. */
    @Modifying
    @Query("UPDATE Usuario u SET u.nombre = :nombre, u.apellido = :apellido, u.direccion = :direccion, "
            + "u.telefono = :telefono WHERE u.idUsuario = :id")
    int actualizarDatos(@Param("id") int idUsuario, @Param("nombre") String nombre,
                        @Param("apellido") String apellido, @Param("direccion") String direccion,
                        @Param("telefono") String telefono);

    /** UsuarioDAO.activarUsuario / inactivarUsuario */
    @Modifying
    @Query("UPDATE Usuario u SET u.estado = :estado WHERE u.idUsuario = :id")
    int cambiarEstado(@Param("id") int idUsuario, @Param("estado") String estado);
}
