package com.latinburger.repository;

import com.latinburger.entity.Producto;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/** Migración de ProductoDAO. */
@Repository
public interface ProductoRepository extends JpaRepository<Producto, Integer> {

    /** ProductoDAO.listar: solo activos. */
    List<Producto> findByActivoTrue();

    /** ProductoDAO.listarPorCategoria: activos de una categoría. */
    List<Producto> findByIdCategoriaAndActivoTrue(int idCategoria);

    /** ProductoDAO.listarTodos: ORDER BY id_categoria, nombre. */
    List<Producto> findAllByOrderByIdCategoriaAscNombreAsc();

    /**
     * Consulta del menú del cliente (MenuServlet.obtenerListaMenu):
     * Producto INNER JOIN Categoria, solo activos, ORDER BY id_categoria, id_producto.
     * Cada fila: [Producto, nombreCategoria].
     */
    @Query("SELECT p, c.nombre FROM Producto p, Categoria c "
            + "WHERE p.idCategoria = c.idCategoria AND p.activo = true "
            + "ORDER BY p.idCategoria, p.idProducto")
    List<Object[]> listarMenuConCategoria();

    /** ProductoDAO.cambiarActivo (ocultar / mostrar). */
    @Modifying
    @Query("UPDATE Producto p SET p.activo = :activo WHERE p.idProducto = :id")
    int cambiarActivo(@Param("id") int idProducto, @Param("activo") boolean activo);
}
