package com.latinburger.repository;

import com.latinburger.entity.TipoMenu;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/** Migración de TipoMenuDAO. */
@Repository
public interface TipoMenuRepository extends JpaRepository<TipoMenu, Integer> {

    /** TipoMenuDAO.buscarPersonalizado: WHERE nombre_menu = ? LIMIT 1. */
    Optional<TipoMenu> findFirstByNombreMenu(String nombreMenu);
}
