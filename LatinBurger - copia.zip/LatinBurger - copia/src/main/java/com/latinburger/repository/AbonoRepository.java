package com.latinburger.repository;

import com.latinburger.entity.Abono;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/** Migración de AbonoDAO. */
@Repository
public interface AbonoRepository extends JpaRepository<Abono, Integer> {

    /** AbonoDAO.listarPorReserva */
    List<Abono> findByReservaIdReservaOrderByFechaAbonoDesc(int reservaIdReserva);

    /**
     * AbonoDAO.listarTodos: abono + reserva + usuario (INNER JOIN).
     * Cada fila: [Abono, idReserva, fechaEvento, nombre, apellido].
     */
    @Query("SELECT a, r.idReserva, r.fecha, u.nombre, u.apellido "
            + "FROM Abono a, Reserva r, Usuario u "
            + "WHERE a.reservaIdReserva = r.idReserva AND r.usuarioIdUsuario = u.idUsuario "
            + "ORDER BY a.fechaAbono DESC")
    List<Object[]> listarTodosConDetalle();

    /** AbonoDAO.sumarAbonosMes */
    @Query(value = "SELECT COALESCE(SUM(valor_abono), 0) AS total FROM abono "
            + "WHERE YEAR(fecha_abono) = :anio AND MONTH(fecha_abono) = :mes", nativeQuery = true)
    Number sumarAbonosMes(@Param("anio") int anio, @Param("mes") int mes);
}
