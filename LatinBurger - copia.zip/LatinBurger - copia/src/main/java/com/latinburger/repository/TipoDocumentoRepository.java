package com.latinburger.repository;

import com.latinburger.entity.TipoDocumento;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/** Migración de TipoDocumentoDAO. */
@Repository
public interface TipoDocumentoRepository extends JpaRepository<TipoDocumento, Integer> {
}
